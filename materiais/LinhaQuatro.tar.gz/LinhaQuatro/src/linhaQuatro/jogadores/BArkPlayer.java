package linhaQuatro.jogadores;

public class BArkPlayer implements Jogador{

	public int[][] matrizDecisao = new int[25][2];
	public int[][] matrizDecisaoAtaque = new int[25][2];
    public int percorre;
    public int percorreAtaque;
    public int buscaMaior;
    public int buscaMaiorAtaque;
    public int valorJogada;
	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return "BArkPlayer!";
	}

	@Override
	public int jogada(int[][] tabuleiro, int corDaMinhaBola) {
		//vers�o 4
        percorre = 0;
        buscaMaior = 0;
        buscaMaiorAtaque = 0;
        //Vers�o 3
        int corDaOutraBola;
        int jogar = -1;
        if(corDaMinhaBola == 1)
            corDaOutraBola = 2;
        else
            corDaOutraBola = 1;
        for(int i = 0; i < matrizDecisao.length ; i ++)
            for(int j = 0; j < matrizDecisao[0].length ; j ++) 
                matrizDecisao[i][j] = 0;
        for(int i = 0; i < tabuleiro.length ; i ++)
            for(int j = 0; j < tabuleiro[0].length ; j ++)
                if(tabuleiro[i][j] == corDaOutraBola)
                {
                    jogar = verDefesa(tabuleiro, corDaOutraBola, i , j);
                    matrizDecisao[percorre][0] = jogar;
                    matrizDecisao[percorre][1] = valorJogada;
                    percorre++;
                }
        for(int i = 0; i < matrizDecisao.length ; i ++)
        {
            if(matrizDecisao[i][1] == 10)
            {
                //System.out.println("Defendeu");
                return matrizDecisao[i][0];
            }
            if(matrizDecisao[i][1] == 5)
            {
                buscaMaior = matrizDecisao[i][0]; 
            }
        }
        percorreAtaque = 0;
        for(int i = 0; i < matrizDecisaoAtaque.length ; i ++)
            for(int j = 0; j < matrizDecisaoAtaque[0].length ; j ++) 
                matrizDecisaoAtaque[i][j] = 0;
        for(int i = 0; i < tabuleiro.length ; i ++)
            for(int j = 0; j < tabuleiro[0].length ; j ++)
                if(tabuleiro[i][j] == corDaMinhaBola)
                {
                    jogar = verDefesa(tabuleiro, corDaMinhaBola, i , j);
                    matrizDecisaoAtaque[percorreAtaque][0] = jogar;
                    matrizDecisaoAtaque[percorreAtaque][1] = valorJogada;
                    percorreAtaque++;
                }
        for(int i = 0; i < matrizDecisaoAtaque.length ; i ++)
        {
            if(matrizDecisaoAtaque[i][1] == 10)
            {
                //System.out.println("Atacou");
                return matrizDecisaoAtaque[i][0];
            }
        }
        if(buscaMaior != 0 && tabuleiro[0][buscaMaior] == 0){
            //System.out.println("Defendeu");
            return buscaMaior;
        }
		try{
			BArkMiniMaxEstado jogo;
			if(corDaMinhaBola==1)
				jogo = new BArkMiniMaxEstado(corDaMinhaBola, 2, 0, tabuleiro);
			else
				jogo = new BArkMiniMaxEstado(corDaMinhaBola, 1, 0, tabuleiro);
			//return BArkMiniMax.getJogada(jogo,6);
			//return BArkMiniMax.getJogada(jogo,8);
			int jogada = BArkMiniMax.getJogada(jogo,7);
			if(tabuleiro[0][jogada] == 0){
				return jogada;
			}
			else{
				return 0;
			}
		}catch(Exception e){
			//System.out.println("Erro: "+e);
			return 0;
		}
	}
	public int verDefesa(int[][] tabuleiro, int corDaOutraBola, int linha, int coluna){
        int jogadaDiagonalEsq = 0,jogadaDiagonalDir = 0,
            jogadaDiagonalEsqEspecifico = 0,jogadaDiagonalDirEspecifico = 0,
            jogadaColuna = 0,jogadaColunaUp = 0,
            y = 0,
            yUp = 0,
            diagonalDir = 0,diagonalEsq = 0,
            diagonalDirEspecifico = 0,diagonalEsqEspecifico = 0;
        if(linha <= tabuleiro.length - 3)
        {
            jogadaColuna = verColuna(tabuleiro, corDaOutraBola, linha, coluna);
            y = valorJogada;
        }
        //vers�o 6 
        /*
         * C�digo para verificar colunas de baixo para cima
         */
        if(linha >= tabuleiro.length - 4)
        {
            jogadaColunaUp = verColunaUp(tabuleiro, corDaOutraBola, linha, coluna);
            yUp = valorJogada;
        }
        if(linha > 3)
        {
            if(coluna <= 3)
            {
                jogadaDiagonalDir = verDiagonalDir(tabuleiro, corDaOutraBola, linha, coluna);
                diagonalDir = valorJogada;
            }
            if(coluna >= 3)
            {
                jogadaDiagonalEsq = verDiagonalEsq(tabuleiro, corDaOutraBola, linha, coluna);
                diagonalEsq = valorJogada;
            }
        }
        if(linha <= 3)
        {
            if(coluna <= 3)
            {
                jogadaDiagonalDirEspecifico = verDiagonalDirEspecifico(tabuleiro, corDaOutraBola, linha, coluna);
                diagonalDirEspecifico = valorJogada;
            }
            if(coluna >= 3)
            {
                jogadaDiagonalEsqEspecifico = verDiagonalEsqEspecifico(tabuleiro, corDaOutraBola, linha, coluna);
                diagonalEsqEspecifico = valorJogada;
            }
        }
        if( y == 10)
        {
            //System.out.println("Retornando jogadaColuna");
            valorJogada = y;
            return jogadaColuna;
        }
        if( yUp == 10)
        {
            //System.out.println("Retornando jogadaColuna");
            valorJogada = yUp;
            return jogadaColunaUp;
        }
        if( diagonalEsq == 10)
        {
            //System.out.println("Retornando diagonalEsq");
            valorJogada = diagonalEsq;
            return jogadaDiagonalEsq;
        }
        if( diagonalDir == 10)
        {
            //System.out.println("Retornando diagonalDir");
            valorJogada = diagonalDir;
            return jogadaDiagonalDir;
        }
        if( diagonalEsqEspecifico == 10)
        {
            //System.out.println("Retornando diagonalEsq");
            valorJogada = diagonalEsqEspecifico;
            return jogadaDiagonalEsqEspecifico;
        }
        if( diagonalDirEspecifico == 10)
        {
            //System.out.println("Retornando diagonalDir");
            valorJogada = diagonalDirEspecifico;
            return jogadaDiagonalDirEspecifico;
        }
        else
            return -1;
    }
	 public int verColuna(int[][] tabuleiro, int corDaOutraBola, int linha, int coluna)
	    {
	        int aux = linha;
	        while(tabuleiro[aux][coluna] == corDaOutraBola)
	        {
	            if(aux <= 6)
	            {
	                aux++;
	            }
	            else
	                break;
	            if(aux == 7)
	                break;
	        }
	        if(aux - linha == 3)
	        {
	            if(linha > 1)
	                if(tabuleiro[linha-1][coluna] == 0)
	                {
	                    valorJogada = 10;
		                if(tabuleiro[0][coluna] == 0){
		                	return coluna;
		    			}
		    			else{
		    				return 0;
		    			}
	            }
	        }
	        valorJogada = 0;
	        return 0;
	    }
	    //versao 6 
	    public int verColunaUp(int[][] tabuleiro, int corDaOutraBola, int linha, int coluna)
	    {
	        int aux = linha;
	        while(tabuleiro[aux][coluna] == corDaOutraBola)
	        {
	            if(aux <= 1)
	            {
	                aux--;
	            }
	            else
	                break;
	            if(aux == 0)
	                break;
	        }
	        if(linha - aux  == 3)
	        {
	                valorJogada = 10;
	                if(tabuleiro[0][coluna] == 0){
	                	return coluna;
	    			}
	    			else{
	    				return 0;
	    			}
	        }
	        valorJogada = 0;
	        return 0;
	    }
	    public int verDiagonalDir(int[][] tabuleiro, int corDaOutraBola,int linha, int coluna)
	    {
	        int aux = 0, colunaZero = 0, colunaAux = coluna, linhaAux = 0;
	        for(int i = linha; i > linha - 4; i --)
	        {
	            if(tabuleiro[i][colunaAux] == corDaOutraBola)
	                aux++;
	            else{
	                linhaAux = i;
	                colunaZero = colunaAux; 
	            }
	            colunaAux++;
	        }
	        if(aux == 3)
	        {
	            if(tabuleiro[linhaAux+1][colunaZero] != 0 && tabuleiro[linhaAux][colunaZero] == 0)
	            {
	                valorJogada = 10;
	                if(tabuleiro[0][colunaZero] == 0){
	                	return colunaZero;
	    			}
	    			else{
	    				return 0;
	    			}
	            } 
	        }
	        valorJogada = 0;
	        return 0;
	    }
	    public int verDiagonalEsq(int[][] tabuleiro, int corDaOutraBola,int linha, int coluna)
	    {
	        int aux = 0, colunaZero = 0, colunaAux = coluna, linhaAux = 0;
	        for(int i = linha; i > linha - 4; i --)
	        {
	            if(tabuleiro[i][colunaAux] == corDaOutraBola)
	                aux++;
	            else{
	                linhaAux = i;
	                colunaZero = colunaAux; 
	            }
	            colunaAux--;
	        }
	        if(aux == 3)
	        {
	            if(tabuleiro[linhaAux+1][colunaZero] != 0 && tabuleiro[linhaAux][colunaZero] == 0)
	            {
	                valorJogada = 10;
	                if(tabuleiro[0][colunaZero] == 0){
	                	return colunaZero;
	    			}
	    			else{
	    				return 0;
	    			}
	            } 
	        }
	        valorJogada = 0;
	        return 0;
	    }
	    public int verDiagonalEsqEspecifico(int[][] tabuleiro, int corDaOutraBola,int linha, int coluna)
	    {
	        int aux = 0, colunaZero = 0, colunaAux = coluna, linhaAux = 0;
	        for(int i = linha; i < linha + 4; i ++)
	        {
	            if(tabuleiro[i][colunaAux] == corDaOutraBola)
	                aux++;
	            else{
	                linhaAux = i;
	                colunaZero = colunaAux; 
	            }
	            colunaAux--;
	        }
	        if(aux == 3)
	        {
	        	if(linhaAux < 6)
	        	{
		            if(tabuleiro[linhaAux+1][colunaZero] != 0 && tabuleiro[linhaAux][colunaZero] == 0)
		            {
		                valorJogada = 10;
		                if(tabuleiro[0][colunaZero] == 0){
		                	return colunaZero;
		    			}
		    			else{
		    				return 0;
		    			}
		            }
	        	}
	        	else
	        	{
		            if(tabuleiro[linhaAux][colunaZero] == 0)
		            {
		                valorJogada = 10;
		                if(tabuleiro[0][colunaZero] == 0){
		                	return colunaZero;
		    			}
		    			else{
		    				return 0;
		    			}
		            }
	        	
	        	}
	        }
	        valorJogada = 0;
	        return 0;
	    }
	    
	    public int verDiagonalDirEspecifico(int[][] tabuleiro, int corDaOutraBola,int linha, int coluna)
	    {
	        int aux = 0, colunaZero = 0, colunaAux = coluna, linhaAux = 0;
	        for(int i = linha; i < linha + 4; i ++)
	        {
	            if(tabuleiro[i][colunaAux] == corDaOutraBola)
	                aux++;
	            else{
	                linhaAux = i;
	                colunaZero = colunaAux; 
	            }
	            colunaAux++;
	        }
	        if(aux == 3)
	        {
	        	if(linhaAux < 6)
	        	{
		            if(tabuleiro[linhaAux+1][colunaZero] != 0 && tabuleiro[linhaAux][colunaZero] == 0)
		            {
		                valorJogada = 10;
		                if(tabuleiro[0][colunaZero] == 0){
		                	return colunaZero;
		    			}
		    			else{
		    				return 0;
		    			}
		            } 
	        	}
	        	else
	        	{
		            if(tabuleiro[linhaAux][colunaZero] == 0)
		            {
		                valorJogada = 10;
		                //System.out.println("Defendeu !");
		                if(tabuleiro[0][colunaZero] == 0){
		                	return colunaZero;
		    			}
		    			else{
		    				return 0;
		    			}
		            }         		
	        	}
	        }
	        valorJogada = 0;
	        return 0;
	    }
}

