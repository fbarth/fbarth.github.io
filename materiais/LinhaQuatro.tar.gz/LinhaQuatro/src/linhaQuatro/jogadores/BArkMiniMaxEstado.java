package linhaQuatro.jogadores;

import java.util.ArrayList;

public class BArkMiniMaxEstado{

	int minhaBola, bolaPai, jogada;
	int[][] tabu;
	
	public BArkMiniMaxEstado (int meu, int pai, int jogo, int[][] tabu){
		this.minhaBola = meu;
		this.bolaPai = pai;
		this.jogada = jogo;
		this.tabu = tabu;
	}
	
	
	public double eval() {
		// Auto-generated method stub
		return funcaoAvaliadora();
	}

	/* funcaoAvaliador verifica pela matriz a utilidade do estado passado.
	 * realiza uma somatoria com as posicoes da matriz e analisa todas as posi��es.
	 * no final retorna o valor do estado que � calculado como:
	 * Soma(minhaBola)-Soma(advBola), ou seja, as posi��es das minhas bolas menos 
	 * as posi��es da bola do adversario*/
	public double funcaoAvaliadora(){
		double auxMinha, auxAdv;
		if(this.minhaBola == 1){
			auxMinha = soma(1);
			auxAdv = soma(2);
		}
		else{
			auxMinha = soma(2);
			auxAdv = soma(1);
		}
		return (auxMinha-auxAdv);
	}
	
	/* soma:
	 * realiza a somatoria conforme a bola passada.
	 */
	public double soma(int qualBola){
		int bolasAvistada = 0;
		double auxSoma = 0;
		//realizar soma de 4 em 4.
		//linhas:
		for(int linha = this.tabu.length-1; linha >= 0; linha--){
			for(int pivo = 0; pivo < 4; pivo++){
				for(int i = pivo; i < (pivo+4); i++){
					if(qualBola == this.tabu[linha][i]){
						bolasAvistada = bolasAvistada +1;
					}
					if((this.tabu[linha][i] != qualBola)
							&& (this.tabu[linha][i] !=0)){
						//para porque encontrou uma bola do outro jogador.
						break;
						}
				}
				switch (bolasAvistada){
					case 0: bolasAvistada = 0; 
						break;
					case 1: auxSoma = auxSoma+2;
							bolasAvistada = 0;
						break;
					case 2: auxSoma = auxSoma+12;
							bolasAvistada = 0;
						break;
					case 3: auxSoma = auxSoma+100;
							bolasAvistada = 0;
						break;
					case 4: auxSoma = auxSoma+2000;
							bolasAvistada = 0;
						break;
					default: bolasAvistada = 0;
						break;
				}
			}
		}
		for(int linha = this.tabu.length-1; linha >= 0; linha--){
			   for(int pivo = 6; pivo > 3; pivo--){
			    for(int i = pivo; i > (pivo-4); i--){
			     if(qualBola == this.tabu[linha][i]){
			      bolasAvistada = bolasAvistada +1;
			     }
			     if((this.tabu[linha][i] != qualBola)
			       && (this.tabu[linha][i] !=0)){
			      //para porque encontrou uma bola do outro jogador.
			      break;
			      }
			    }
			    switch (bolasAvistada){
			     case 0: bolasAvistada = 0; 
			      break;
			     case 1: auxSoma = auxSoma+2;
			       bolasAvistada = 0;
			      break;
			     case 2: auxSoma = auxSoma+12;
			       bolasAvistada = 0;
			      break;
			     case 3: auxSoma = auxSoma+100;
			       bolasAvistada = 0;
			      break;
			     case 4: auxSoma = auxSoma+2000;
			       bolasAvistada = 0;
			      break;
			     default: bolasAvistada = 0;
			      break;
			    }
			   }
			  }
		//Colunas:
		bolasAvistada = 0;
		for(int coluna = 0; coluna < this.tabu.length; coluna++){
			for(int pivo = 6; pivo > 2; pivo--){
				for(int i = pivo; i > (pivo-4); i--){
					if((qualBola == this.tabu[i][coluna])){
						bolasAvistada = bolasAvistada +1;
					}
					if((this.tabu[i][coluna] != qualBola)
						&& (this.tabu[i][coluna] !=0)){
						//para porque encontrou uma bola do outro jogador.
						break;
					}
				}
				switch (bolasAvistada){
					case 0: bolasAvistada = 0; 
						break;
					case 1: auxSoma = auxSoma+2;
							bolasAvistada = 0;
						break;
					case 2: auxSoma = auxSoma+12;
							bolasAvistada = 0;
						break;
					case 3: auxSoma = auxSoma+100;
							bolasAvistada = 0;
						break;
					case 4: auxSoma = auxSoma+2000;
							bolasAvistada = 0;
						break;
					default: bolasAvistada = 0;
						break;
				}
			}
		}
		//Diagonal Esquerda para Direita(ex.(0,6)->(6,0)):
		//diagonais a baixo da pincipal:
        int limitante = 2;
        //System.out.println("diagonais a baixo da pincipal");
        for(int linha = 6; linha > limitante; linha--){
        	int auxLinha = linha;
            //System.out.println("auxColuna = "+auxLinha);
            for(int coluna = 0; coluna < 4; coluna++){
                auxLinha = linha;
                int auxColuna = coluna;
                //System.out.println("auxLinha = "+auxColuna);
                for(int i = linha; i > (linha-4); i--){
                    //System.out.println("Verifica = Linha " + auxLinha + "Coluna " +auxColuna);
                    if(qualBola == this.tabu[auxLinha][auxColuna]){
                        bolasAvistada = bolasAvistada +1;
                    }
                    if((qualBola != this.tabu[auxLinha][auxColuna])
                        && (this.tabu[auxLinha][auxColuna] != 0)){
                        //para porque encontrou uma bola do outro jogador.
                        break;
                    }
                    auxLinha--;
                    auxColuna++;
                }
                auxColuna = coluna + 1;
                switch (bolasAvistada){
                case 0: bolasAvistada = 0;
                    break;
                case 1: auxSoma = auxSoma+2;
                        bolasAvistada = 0;
                    break;
                case 2: auxSoma = auxSoma+12;
                        bolasAvistada = 0;
                    break;
                case 3: auxSoma = auxSoma+100;
                        bolasAvistada = 0;
                    break;
                case 4: auxSoma = auxSoma+2000;
                        bolasAvistada = 0;
                    break;
                default: bolasAvistada = 0;
                    break;
                }
            }
        }
        //Diagonal Direita para Esquerda(ex.(6,6)->(0,0)):
        //diagonal principal para cima:
        bolasAvistada = 0;
        limitante = 2;
        //System.out.println("diagonal principal para cima");
        for(int sobeUmaLinha = 6; sobeUmaLinha > 2; sobeUmaLinha--){
        	int auxLinha = sobeUmaLinha;
            //System.out.println("auxL = linha" + auxLinha + "" +sobeUmaLinha);
            for(int coluna = 6; coluna > limitante; coluna--){
                int auxColuna = coluna;
                auxLinha = sobeUmaLinha;
                //System.out.println("auxC = coluna" + auxColuna + "" +coluna);
                for(int i = coluna; i > (coluna-4); i--){
                    //System.out.println("Verifica = Linha " + auxLinha + "Coluna " +auxColuna);
                    if(qualBola == this.tabu[auxLinha][auxColuna]){
                        bolasAvistada = bolasAvistada +1;
                    }
                    if((qualBola != this.tabu[auxLinha][auxColuna])
                       && (this.tabu[auxLinha][auxColuna] != 0)){
                        //para porque encontrou uma bola do outro jogador.
                        break;
                    }
                    auxLinha--;
                    auxColuna--;
                }
                //System.out.println("Saiu do Primeiro For");
                switch (bolasAvistada){
                    case 0: bolasAvistada = 0;
                        break;
                    case 1: auxSoma = auxSoma+2;
                            bolasAvistada = 0;
                        break;
                    case 2: auxSoma = auxSoma+12;
                            bolasAvistada = 0;
                        break;
                    case 3: auxSoma = auxSoma+100;
                            bolasAvistada = 0;
                        break;
                    case 4: auxSoma = auxSoma+2000;
                            bolasAvistada = 0;
                        break;
                    default: bolasAvistada = 0;
                        break;
                }
            }
            //System.out.println("Saiu do Segundo For");
        } 
		return auxSoma;
	}
	/*
	 * (non-Javadoc)
	 * @see EstadoUtilidade#sucessors()
	 */
	
	public ArrayList <BArkMiniMaxEstado> sucessors() {
		// Auto-generated method stub
		ArrayList<BArkMiniMaxEstado> filhos = new ArrayList<BArkMiniMaxEstado>();
		for(int jogada=0; jogada < 7; jogada++){
			for(int i = 6; i > -1; i--){
				if(this.tabu[i][jogada]==0){
					int[][] tabuFilho;
					tabuFilho = incrivelTranferidorDeTabu(this.tabu);
					tabuFilho[i][jogada]=this.minhaBola;
					if(this.bolaPai == 1){
						tabuFilho[i][jogada] = 2;
						//System.out.println(this.printTabuleiro(tabuleiroTemp));
						filhos.add(new BArkMiniMaxEstado(this.minhaBola,2,jogada,tabuFilho));
					}
					else{
						tabuFilho[i][jogada]=1;
						//System.out.println(this.printTabuleiro(tabuleiroTemp));
						filhos.add(new BArkMiniMaxEstado(this.minhaBola,1,jogada,tabuFilho));
					}
					break;
				}
			}
		}
		return filhos;
	}
	/*
	 * O incrivelTranferidorDeTabu:
	 * transfere o tabuleiro, baseado no codigo
	 * incrivelSetadorDeDestino.
	 */
	public int[][] incrivelTranferidorDeTabu(int [][]t) {
		int [][] aux = new int[7][7];
		for(int i=0; i < 7; i++){
			for(int j=0; j < 7; j++){	
				aux[i][j]= t[i][j];
			}
		}
		return aux;
	}

	public int getJogada() {
		// TODO Auto-generated method stub
		return this.jogada;
	}

	public String printTabuleiro() {
		// TODO Auto-generated method stub
		return null;
	}

}
