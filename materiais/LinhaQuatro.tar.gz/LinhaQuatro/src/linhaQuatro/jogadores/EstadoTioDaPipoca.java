package linhaQuatro.jogadores;

import java.util.ArrayList;

/**
 * Projeto P2 - Competição de quatro em uma linha
 * Bacharelado em Ciência da Computação
 * Laboratório de Programação IV - IA
 * Alunos: Alexander, Leidiane e Luiz Paulo
 * Jogador: Tio da Pipoca
 */
public class EstadoTioDaPipoca implements EstadoUtilidade {

    // Propiedades usadas na classe
    private int[][] tabuleiro;
    private int corDaMinhaBola;
    private int jogada;
    private int jogadorAnterior;

    /**
     * Construtor principal da classe
     * @param tabuleiro
     * @param corDaMinhaBola
     * @param jogada
     * @param jogadorAnterior
     */
    public EstadoTioDaPipoca(int[][] tabuleiro, int corDaMinhaBola, int jogada, int jogadorAnterior) {
        this.tabuleiro = TioDaPipoca.copiaTabuleiro(tabuleiro);
        this.corDaMinhaBola = corDaMinhaBola;
        this.jogada = jogada;
        this.jogadorAnterior = jogadorAnterior;
    }

    /**
     * Método que avalia um estado
     * @return double
     */
    public double eval() {
        int i = (verificaSul(corDaMinhaBola) +
                verificaSudoeste(corDaMinhaBola) +
                verificaOeste(corDaMinhaBola) +
                verificaNoroeste(corDaMinhaBola) +
                verificaNordeste(corDaMinhaBola) +
                verificaLeste(corDaMinhaBola) +
                verificaSudeste(corDaMinhaBola));
        return i;
    }

    /**
     * Método que cria os sucessores de um estado
     * @return ArrayList
     */
    public ArrayList<EstadoUtilidade> sucessors() {
        ArrayList<EstadoUtilidade> sucessores = new ArrayList<EstadoUtilidade>();
        for (int possivelJogada = 0; possivelJogada < 7; possivelJogada++) {
            for (int i = 6; i >= 0; i--) {
                if (tabuleiro[i][possivelJogada] == 0) {
                    int[][] temp = TioDaPipoca.copiaTabuleiro(tabuleiro);
                    if (this.jogadorAnterior == 1) {
                        temp[i][possivelJogada] = 2;
                        sucessores.add(new EstadoTioDaPipoca(temp, this.corDaMinhaBola, possivelJogada, 2));
                    } else {
                        temp[i][possivelJogada] = 1;
                        sucessores.add(new EstadoTioDaPipoca(temp, this.corDaMinhaBola, possivelJogada, 1));
                    }
                    break;
                }
            }
        }
        return sucessores;
    }

    /**
     * Método que retorna a jogada
     * @return int
     */
    public int getJogada() {
        return this.jogada;
    }

    /**
     * Método que retorna a ultima linha da jogada,
     * ou seja, onde foi efetuada a jogada
     * @return int
     */
    public int ultimaLinhaDaColuna() {
        for (int i = 0; i < 7; i++) {
            if (tabuleiro[i][jogada] != 0) {
                return i;            // returno padrao da funcao(esperamos que não ocorra)
            }
        }
        return -1;
    }

    /**
     * Método para verificação no Sul da jogada
     */
    public int verificaSul(int jogador) {
        int count = 0;
        try {
            if (tabuleiro[ultimaLinhaDaColuna() + 1][jogada] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna() + 2][jogada] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna() + 3][jogada] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        
        return count;
    }

    /**
     * Método para verificação no Oeste da jogada
     */
    public int verificaOeste(int jogador) {
        int count = 0;
        try {
            if (tabuleiro[ultimaLinhaDaColuna()][jogada - 1] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna()][jogada - 2] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna()][jogada - 3] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        
        return count;
    }

    /**
     * Método para verificação no Leste da jogada
     */
    public int verificaLeste(int jogador) {
        int count = 0;
        try {
            if (tabuleiro[ultimaLinhaDaColuna()][jogada + 1] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna()][jogada + 2] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna()][jogada + 3] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }

        return count;
    }

    /**
     * Método para verificação no Nordeste da jogada
     */
    public int verificaNordeste(int jogador) {
        int count = 0;
        try {
            if (tabuleiro[ultimaLinhaDaColuna() - 1][jogada + 1] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna() - 2][jogada + 2] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna() - 3][jogada + 3] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        
        return count;
    }

    /**
     * Método para verificação no Noroeste da jogada
     */
    public int verificaNoroeste(int jogador) {
        int count = 0;
        try {
            if (tabuleiro[ultimaLinhaDaColuna() - 1][jogada - 1] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna() - 2][jogada - 2] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna() - 3][jogada - 3] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        
        return count;
    }

    /**
     * Método para verificação no Suldoeste da jogada
     */
    public int verificaSudoeste(int jogador) {
        int count = 0;
        try {
            if (tabuleiro[ultimaLinhaDaColuna() + 1][jogada - 1] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna() + 2][jogada - 2] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna() + 3][jogada - 3] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }

        return count;
    }

    /**
     * Método para verificação no Sudeste da jogada
     */
    public int verificaSudeste(int jogador) {
        int count = 0;
        try {
            if (tabuleiro[ultimaLinhaDaColuna() + 1][jogada + 1] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna() + 2][jogada + 2] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        try {
            if (tabuleiro[ultimaLinhaDaColuna() + 3][jogada + 3] == jogador) {
                count++;
            }
        } catch (Exception e) {
            return count;
        }
        
        return count;
    }
}
