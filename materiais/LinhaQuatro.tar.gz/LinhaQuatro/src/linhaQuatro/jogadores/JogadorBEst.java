package linhaQuatro.jogadores;

import java.util.*;

/**
 * Inteligência Artificial para um jogador de Connect 4.
 *
 * @author Bruno Prado e Edgar Cintho
 */
public class JogadorBEst implements Jogador {

    /**
     * Profundidade atual da árvore.
     */
    private static int recurDepth = 0;
    /**'
     * Profundidade máxima que o algoritmo irá percorrer a árvore.
     */
    private static final int MAX_RECURDEPTH = 7;
    /**
     * Ordem das colunas para simular as colocações das peças
     */
    private static final int[] bestOrder = {3, 2, 4, 1, 5, 0, 6};
    /**
     * Largura e Altura do tabuleiro.
     */
    private static int WIDTH, HEIGHT;
    /**
     * Tabuleiro do jogo.
     */
    private int[][] board;
    /**
     * Armazena a quantidade de peças que uma coluna já possui.
     */
    private int[] columnHeight;
    /**
     * Armazena a cor da minha peça.
     */
    private int me;

    /**
     * Construtor vazio chamado pelo gerenciador da competição.
     */
    public JogadorBEst() {
    }

    /**
     * Método chamado pelo gerenciador da competição.
     *
     * Nele é inicializado alguns trechos principais necessários para a busca da melhor jogada
     * e é, também, chamado o método NegaMax que irá realizar a busca.
     *
     * @param tabuleiro Tabuleiro do jogo no momento atual.
     * @param corDaMinhaBola Cor da minha peça
     * @return Coluna que deverá ser jogada a minha peça
     */
    public int jogada(int[][] tabuleiro, int corDaMinhaBola) {
        //Armazena nas variáveis globais qual o tamanho do tabuleiro (Largura e Altura)
        getBoardLength(tabuleiro);
        //Inicializa o vetor com a quantidade de peças que cada coluna já possui no momento.
        getColumnHeight(tabuleiro);

        /**
         * Armazena o tabuleiro de jogo, realizando uma cópia do tabuleiro original.
         * Isto evita que os cálculos alterem o tabuleiro original durante a execução da busca.
         * Além de auxiliar o algoritmo de minimax na colocação de peças com apenas um valor (o da coluna),
         * sem que este precise verificar qual linha irá utilizar, por este fato que o tabuleiro é rotacionado.
         */
        this.board = copyBoard(tabuleiro);
        //Armazena a cor da minha peça
        this.me = corDaMinhaBola;

        //Variável que irá armazenar a coluna que irei jogar na próxima rodada.
        int action = 0;

        //Variável que armazena o valor da melhor jogada.
        int value = 0;

        //Vetor com os movimentos encontrados.
        //Utilizado caso mais de um movimento possua o mesmo valor, assim iremos
        //embaralhar o vetor e sortear um dos movimentos.
        Vector moves = new Vector();

        //Inicializa um valor mínimo que será utilizado para armazenar os valores
        //encontrados, e compará-los com o melhor valor já encontrado.
        int prevValue = Integer.MIN_VALUE + 1;

        //Realiza uma busca para cada uma das sete possibilidades de jogo.
        for (int col : bestOrder) {
            //Verifica se nesta coluna pode ser colocada uma peça ou se ela já esta cheia.
            if (columnHeight[col] >= HEIGHT) {
                continue; //Caso esteja cheia, ignora a coluna e continua.
            }

            //Verifica o valor deste movimento, jogando a peça nesta coluna.
            value = negamax(this.me, col);

            //Se o valor encontrado for maior que o valor anterior.
            if (value > prevValue) {
                //Remove todos os elementos da lista de movimentos iguais.
                moves.removeAllElements();
                //E armazena este valor atual.
                prevValue = value;
            }

            //Se o valor encontrado for igual ao valor anterior.
            if (value == prevValue) {
                //Então armazena na lista mais um movimento com valor igual.
                moves.add(new Integer(col));
            }
        }

        //Verifica a quantidade de movimentos encontrados.
        //Caso tenha mais de um, pega a coluna de maior peso (definida pelo vetor
        //bestOrder.
        if (moves.size() > 0) {
            for (int o : bestOrder) {
                if (moves.contains(o)) {
                    action = o;
                    break;
                }
            }
        }

        //Retorna a coluna escolhida.
        return action;
    }

    /**
     * Armazena a Largura e a Altura do tabuleiro.
     *
     * @param board Tabuleiro a ser analizado.
     */
    private void getBoardLength(int[][] board) {
        WIDTH = board.length;
        HEIGHT = board[0].length;
    }

    /**
     * Armazena a quantidade de peças que uma coluna já possui.
     *
     * @param board Tabuleiro a ser analizado.
     */
    private void getColumnHeight(int[][] board) {
        //Inicializa o vetor de quantidade de peças por coluna com o tamanho correto.
        columnHeight = new int[WIDTH];

        //Analiza o mapa e armazena a quantidade correta.
        int aux = 0;
        for (int col = 0; col < WIDTH; col++) {
            for (int row = 0; row < HEIGHT; row++) {
                //Contabiliza os espaços em branco de cada coluna.
                if (board[row][col] == 0) {
                    aux++;
                }
            }
            //Pega a altura total e subtrai com a quantidade de espaços em branco encontrados
            //na coluna.
            columnHeight[col] = HEIGHT - aux;
            aux = 0;
        }
    }

    /**
     * Copia o tabuleiro realizando uma rotação no mesmo para a direita.
     *
     * Isto é feito pois facilida o algoritmo de negamax na construção dos sucessores de um
     * estado, sendo que este apenas utiliza o valor da coluna, sem precisar buscar pelo
     * valor da linha, evitando cálculos desnecessários e diminuindo o tempo de execução do
     * mesmo.
     *
     * @param board Tabuleiro a ser copiado e rotacionado.
     * @return A cópia do tabuleiro.
     */
    private int[][] copyBoard(int[][] board) {
        int[][] copia = new int[WIDTH][HEIGHT];

        int aux = 0;
        for (int row = WIDTH - 1; row >= 0; row--) {
            for (int col = 0; col < HEIGHT; col++) {
                //Rotaciona o tabuleiro para a direita.
                copia[col][aux] = board[row][col];
            }
            aux++;
        }
        return copia;
    }

    /**
     * Método NegaMax implementado de forma recursiva (evitando a criação de dois métodos
     * Max e Min, e o gasto de tempo na criação de sucessores antes do necessário).
     *
     * Ele sempre retorna o valor máximo para cada jogador e intepreta de maneira que
     * meu oponente sempre seja prejudicado.
     *
     * @param player Número do jogador a ser utilizado na jogada atual.
     * @param column Coluna a ser jogada.
     * @return Valor desta jogada.
     */
    int negamax(int player, int column) {
        //Verifica se nesta coluna é possível colocar uma peça
        if (columnHeight[column] >= HEIGHT) {
            //Retorna valor 0 caso não seja possível (Indica que é uma folha e este movimento tem valor nulo).
            return 0;
        }

        //Inicializa a variável que armazenará o valor do movimento.
        //Ele irá depender do valor de seus filhos.
        int value = 0;

        //Trecho no qual iremos simular a movimentação.
        doMove(column, player);

        //Verifica o valor do mapa no contexto atual.
        int eval = eval(player);
        //Caso seja maior que 0, então armazena o valo encontrado e subtrai à
        //profundidade atual da árvore (Serve para escolher sempre a opção que chegue
        //na vitória mais rápido)
        if (eval > 0) {
            value = eval - recurDepth;
        }

        //Irá prosseguir na árvore se a profundidade ainda não atingiu a profundidade máxima definida, ou
        //se o valor continua igual a zero, ou seja, nenhum jogador está vencendo neste estado.
        //(Isto realiza uma pequena poda, pois não precisa continuar a busca nestes casos),
        //ou se o valor / 5000 é menor que 1 (Pois o peso de uma vitória ou derrota é maior que 5000),
        //sendo assim, se não for uma vitória ou derrota, iremos continuar na busca na árvore.
        if (recurDepth < MAX_RECURDEPTH && (value == 0 || (value / 5000) < 1)) {
            //Apenas definiremos um valor inicial caso o mapa não possua uma pontuação
            //no contexto atual
            if (value == 0) {
                //Caso o jogador atual seja a minha peça, inicializo com o maior valor
                //possível e vice versa.
                if (player == this.me) {
                    value = Integer.MAX_VALUE - 1;
                } else {
                    value = Integer.MIN_VALUE + 1;
                }
            }

            //Realiza o mesmo procedimento para os filhos deste estado.
            for (int col : bestOrder) {
                //Verifica se é possível colocar uma peça nesta coluna.
                //Isso verifica se nesta determinada coluna ele possui um filho ou não.
                if (columnHeight[col] >= HEIGHT) {
                    continue; //Caso não seja possível, simplesmente continua na busca de outros filhos.
                }

                //Chama o método novamente para este filho passando o próximo jogador e a coluna definida.
                //E armazena o valor encontrado referente a uma relação completa de todos seus filhos, netos.....
                int sucValue = -negamax(3 - player, col); //Nega o valor sempre, por isso é possível dar o mesmo Eval.

                /* Após a análise de todos os filhos iremos verificar o valor de cada um até que
                 * chegue no primeiro nó */

                //Se for a folha, ou seja, nenhum valor foi definido ainda (ele está com o valor padrão).
                if (value == (Integer.MAX_VALUE - 1) || value == (Integer.MIN_VALUE + 1)) {
                    value = sucValue; //Então define o valor atual como o valor encontrado
                } else if (player == this.me) { //Caso o jogador atual deste estado seja o meu.
                    if (value > sucValue) { //Se o valor atualmente armazenado for maior que o valor dos meus filhos.
                        //Atualiza este valor pois este tem uma relação direta com o valor dos filhos
                        //Ja que o jogo continua, e o valor dos filhos é relevante.
                        value = sucValue;
                    }
                } else if (sucValue < value) { //Caso seja meu oponente e o valor dos sucessores seja menor que o valor atual
                    //Então atualiza o valor para o valor deçes, minimizando a chance do adversário.
                    value = sucValue;
                }
            }
        }

        //Trecho no qual iremos remover a simulação da movimentação.
        //Iremos voltar na árvore.
        undoMove(column);

        //Retorna o valor total deste movimento. (Calculado juntamente com o valor de todos seus filhos).
        return value;
    }

    /**
     * Simula uma movimentação em uma determinada posição de um determinado
     * jogador.
     *
     * @param column Número da coluna para simular a movimentação da peça
     * @param player Jogador que será simulado.
     */
    void doMove(int column, int player) {
        recurDepth++; //Aumenta a profuncidade atual.
        this.board[column][columnHeight[column]] = player; //Coloca o jogador.
        columnHeight[column]++; //Aumenta a quantidade de peças que tem na coluna.
    }

    /**
     * Desfaz a simulação de um movimento.
     *
     * @param column Coluna a retirar uma peça.
     */
    void undoMove(int column) {
        recurDepth--; //Diminui a profundidade atual
        columnHeight[column]--; //Diminui o valor de peças na coluna
        this.board[column][columnHeight[column]] = 0; //Remove a peça colocada.
    }

    /**
     * Verifica a pontuação do mapa no contexto atual.
     * É otimizado com o menor número de iterações possíveis para diminuir
     * o tempo total da busca.
     *
     * @param player Jogador a verificar como base na pontuação.
     * @return Pontuação do mapa.
     */
    int eval(int player) {
        int eval = 0;

        //Verifica quantas peças iguais tem do jogador desejado na vertical.
        //E pontua conforme o necessário.
        for (int row = 0; row < WIDTH - 3; row++) {
            for (int col = 0; col < HEIGHT; col++) {
                if (this.board[col][row] != 0 && this.board[col][row] == player) {
                    if (this.board[col][row] == this.board[col][row + 1]) {
                        if (this.board[col][row] == this.board[col][row + 2]) {
                            if (this.board[col][row] == this.board[col][row + 3]) {
                                eval += MAX_RECURDEPTH * 5000; //Caso tenha 4 peças juntas.
                            } else if (this.board[col][row + 3] == 0) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            }
                        } else if (this.board[col][row + 2] == 0) {
                            if (this.board[col][row] == this.board[col][row + 3]) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            } else if (this.board[col][row + 3] == 0) {
                                eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                        }
                    } else if (this.board[col][row + 1] == 0) {
                        if (this.board[col][row] == this.board[col][row + 2] &&
                                this.board[col][row] == this.board[col][row + 3]) {
                            eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                        } else if (this.board[col][row + 2] == 0 &&
                                this.board[col][row] == this.board[col][row + 3]) {
                            eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                        } else if (this.board[col][row] == this.board[col][row + 2] &&
                                this.board[col][row + 3] == 0) {
                            eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                        }
                    }
                } else if (this.board[col][row] == 0) {
                    if (this.board[col][row + 1] == player) {
                        if (this.board[col][row + 2] == player) {
                            if (this.board[col][row + 3] == player) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            } else if (this.board[col][row + 3] == 0) {
                                eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                        } else if (this.board[col][row + 2] == 0 &&
                                this.board[col][row + 3] == player) {
                            eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                        }
                    } else if (this.board[col][row + 1] == 0 &&
                            this.board[col][row + 2] == player &&
                            this.board[col][row + 3] == player) {
                        eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                    }
                }
            }
        }

        //Verifica quantas peças iguais tem do jogador na horizontal.
        //Lembrando que o mapa esta virado para a direita.
        for (int row = 0; row < WIDTH; row++) {
            for (int col = 0; col < HEIGHT - 3; col++) {
                if (this.board[col][row] != 0 && this.board[col][row] == player) {
                    if (this.board[col][row] == this.board[col + 1][row]) {
                        if (this.board[col][row] == this.board[col + 2][row]) {
                            if (this.board[col][row] == this.board[col + 3][row]) {
                                eval += MAX_RECURDEPTH * 5000; //Caso tenha 4 peças juntas.
                            } else if (this.board[col + 3][row] == 0) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            }
                        } else if (this.board[col + 2][row] == 0) {
                            if (this.board[col][row] == this.board[col + 3][row]) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            } else if (this.board[col + 3][row] == 0) {
                                eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                        }
                    } else if (this.board[col + 1][row] == 0) {
                        if (this.board[col][row] == this.board[col + 2][row]) {
                            if (this.board[col][row] == this.board[col + 3][row]) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            } else if (this.board[col + 3][row] == 0) {
                                eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                        } else if (this.board[col + 2][row] == 0 &&
                                this.board[col][row] == this.board[col + 3][row]) {
                            eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                    }
                } else if (this.board[col][row] == 0) {
                    if (this.board[col + 1][row] == player) {
                        if (this.board[col + 2][row] == player) {
                            if (this.board[col + 3][row] == player) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            } else if (this.board[col + 3][row] == 0) {
                                eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                        } else if (this.board[col + 2][row] == 0 &&
                                this.board[col + 3][row] == player) {
                            eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                        }
                    } else if (this.board[col + 1][row] == 0 &&
                            this.board[col + 2][row] == player &&
                            this.board[col + 3][row] == player) {
                        eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                    }
                }
            }
        }

        //Verifica quantas peças iguais tem do jogador na diagonal normal.
        for (int row = 0; row < WIDTH - 3; row++) {
            for (int col = 0; col < HEIGHT - 3; col++) {
                if (this.board[col][row] != 0 && this.board[col][row] == player) {
                    if (this.board[col][row] == this.board[col + 1][row + 1]) {
                        if (this.board[col][row] == this.board[col + 2][row + 2]) {
                            if (this.board[col][row] == this.board[col + 3][row + 3]) {
                                eval += MAX_RECURDEPTH * 5000; //Caso tenha 4 peças juntas.
                            } else if (this.board[col + 3][row + 3] == 0) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            }
                        } else if (this.board[col + 2][row + 2] == 0) {
                            if (this.board[col][row] == this.board[col + 3][row + 3]) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            } else if (this.board[col + 3][row + 3] == 0) {
                                eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                        }
                    } else if (this.board[col + 1][row + 1] == 0) {
                        if (this.board[col][row] == this.board[col + 2][row + 2]) {
                            if (this.board[col][row] == this.board[col + 3][row + 3]) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            } else if (this.board[col + 3][row + 3] == 0) {
                                eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                        } else if (this.board[col + 2][row + 2] == 0 &&
                                this.board[col][row] == this.board[col + 3][row + 3]) {
                            eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                        }
                    }
                } else if (this.board[col][row] == 0) {
                    if (this.board[col + 1][row + 1] == player) {
                        if (this.board[col + 2][row + 2] == player) {
                            if (this.board[col + 3][row + 3] == player) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            } else if (this.board[col + 3][row + 3] == 0) {
                                eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                        } else if (this.board[col + 2][row + 2] == 0 &&
                                this.board[col + 3][row + 3] == player) {
                            eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                        }
                    } else if (this.board[col + 1][row + 1] == 0 &&
                            this.board[col + 2][row + 2] == player &&
                            this.board[col + 3][row + 3] == player) {
                        eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                    }
                }
            }
        }

        //Verifica quantas peças iguais tem do jogador na diagonal reversa.
        for (int row = 0; row < WIDTH - 3; row++) {
            for (int col = 3; col < HEIGHT; col++) {
                if (this.board[col][row] != 0 && this.board[col][row] == player) {
                    if (this.board[col][row] == this.board[col - 1][row + 1]) {
                        if (this.board[col][row] == this.board[col - 2][row + 2]) {
                            if (this.board[col][row] == this.board[col - 3][row + 3]) {
                                eval += MAX_RECURDEPTH * 5000; //Caso tenha 4 peças juntas.
                            } else if (this.board[col - 3][row + 3] == 0) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            }
                        } else if (this.board[col - 2][row + 2] == 0) {
                            if (this.board[col][row] == this.board[col - 3][row + 3]) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            } else if (this.board[col - 3][row + 3] == 0) {
                                eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                        }
                    } else if (this.board[col - 1][row + 1] == 0) {
                        if (this.board[col][row] == this.board[col - 2][row + 2]) {
                            if (this.board[col][row] == this.board[col - 3][row + 3]) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            } else if (this.board[col - 3][row + 3] == 0) {
                                eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                        } else if (this.board[col - 2][row + 2] == 0 &&
                                this.board[col][row] == this.board[col - 3][row + 3]) {
                            eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                    }
                } else if (this.board[col][row] == 0) {
                    if (this.board[col - 1][row + 1] == 0) {
                        if (this.board[col - 2][row + 2] == player) {
                            if (this.board[col - 3][row + 3] == player) {
                                eval += MAX_RECURDEPTH * 50; //Caso tenha 3 peças juntas e um espaço em branco para finalizar.
                            } else if (this.board[col - 3][row + 3] == 0) {
                                eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                        } else if (this.board[col - 2][row + 2] == 0 &&
                                this.board[col - 3][row + 3] == player) {
                            eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                            }
                    } else if (this.board[col - 1][row + 1] == 0 &&
                            this.board[col - 2][row + 2] == player &&
                            this.board[col - 3][row + 3] == player) {
                        eval += MAX_RECURDEPTH / 5; //Caso tenha 2 peças juntas e dois espaços em branco para finalizar.
                    }
                }
            }
        }

        //Retorna a pontuação encontrada.
        return eval;
    }

    /**
     * Retorna o nome do nosso jogador para o gerenciador da
     * competição.
     *
     * @return O nome do nosso jogador.
     */
    public String getNome() {
        return "Jogador BEst";
    }

    /**
     * Método utilizado para DEBUG, onde imprime o estado atual
     * do tabuleiro.
     *
     * OBS.: Copiado do Algoritmo JogadorMinMax do professor
     * Fabrício.
     *
     * @return String com a representação do tabuleiro.
     */
    public String printTabuleiro() {
        String resultado = "";
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                resultado = resultado + " | " + this.board[i][j];
            }
            resultado = resultado + " | " + "\n";
        }
        return resultado;
    }
}
