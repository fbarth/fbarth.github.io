package linhaQuatro.jogadores;

import java.util.ArrayList;

/**
 * -------------------------------------------------------
 * CLASSE REUTILIZADA DO PROFESSOR
 * ALTERAÇÕES:
 *  - ACRESCENTADO UMA VERIFICAÇÃO NO MAIOR VALOR, CASO EXISTA
 * UM MESMO VALOR ANTERIORMENTE OBTIDO, É ESCOLHIDA A COLUNA
 * COM O MAIOR VALOR OBTIDO PELO VETOR DE PRIORIDADE
 * -------------------------------------------------------
 * 
 * Projeto P2 - Competição de quatro em uma linha
 * Bacharelado em Ciência da Computação
 * Laboratório de Programação IV - IA
 * Alunos: Alexander, Leidiane e Luiz Paulo
 * Jogador: Tio da Pipoca
 */
public class MinMaxTioDaPipoca {

    private static EstadoUtilidade maiorEstado;

    private static double maxValue(EstadoUtilidade estado, int profundidade) {
        int[] melhorJogada = {2, 4, 6, 7, 5, 3, 1};
        int ultJogada = 0;
        if (profundidade == 0) {
            return estado.eval();
        }
        double v = -10000; //infinito negativo
        profundidade = profundidade - 1;
        ArrayList<EstadoUtilidade> s = estado.sucessors();
        for (int i = 0; i < s.size(); i++) {
            double valor = minValue(s.get(i), profundidade);
            if (valor == v) {
                if (melhorJogada[i] > melhorJogada[ultJogada]) {
                    v = valor;
                    ultJogada = i;
                    maiorEstado = s.get(i);
                } else {
                    v = valor;
                    maiorEstado = s.get(ultJogada);
                }
            } else if (valor > v) {
                v = valor;
                ultJogada = i;
                maiorEstado = s.get(i);
            }
        }
        return v;
    }

    private static double minValue(EstadoUtilidade estado, int profundidade) {
        if (profundidade == 0) {
            return estado.eval();
        }
        double v = 10000; //infinito positivo
        profundidade = profundidade - 1;
        ArrayList<EstadoUtilidade> s = estado.sucessors();
        for (int i = 0; i < s.size(); i++) {
            v = Math.min(v, maxValue(s.get(i), profundidade));
        }
        return v;
    }

    /**
     * A função deste método é retornar a operação
     * que o jogador deve efetuar.
     *
     * @return
     */
    public static int getJogada(EstadoUtilidade estado, int profundidade) {
        maxValue(estado, profundidade);
        return maiorEstado.getJogada();
    }
}