/**
 * @author Adriano T. Tanaka
 * 		   Aline K. Miyazaki
 * 		   Guilherme P. Rey
 */
package linhaQuatro.jogadores.BOPE;

import java.util.ArrayList;

public interface EstadoMinimax {
	
	public double avaliar();
	
	public ArrayList<EstadoMinimax> sucessores();
	
	public int decidirJogada();
	
	public boolean isTerminal(); 
	
	public String printTabuleiro();

}
