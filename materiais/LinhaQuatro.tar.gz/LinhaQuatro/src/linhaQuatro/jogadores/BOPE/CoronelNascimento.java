/**
 * @author Adriano T. Tanaka
 * 		   Aline K. Miyazaki
 * 		   Guilherme P. Rey
 */
package linhaQuatro.jogadores.BOPE;

import java.util.Random;

import linhaQuatro.jogadores.Jogador;

public class CoronelNascimento implements Jogador
{
	private BatalhaoAnalisador analisador;
	
	private int contador;
	
	public CoronelNascimento()
	{
		this.contador = 0;
	}
	
	@Override
	public String getNome() {
		return "<Coronel Nascimento | BOPE>";
	}

	@Override
	public int jogada(int[][] tabuleiro, int corDaMinhaBola) {
		analisador = new BatalhaoAnalisador(tabuleiro);
		
		if(analisador.isEmpty())
			this.contador = 0;
		else
			this.contador++;
		
		int corAdversario = corDaMinhaBola == 1 ? 2: 1;
		
		try 
		{
			// Primeira jogada
			if(this.contador == 1)
			{
				Random r = new Random();
				int jogada = r.nextInt(3);
				if(jogada == 1) return 3;
				else if(jogada == 2) return 4;
				else return 2;
				
			}
			
			int colunaPossivelJog = analisador.posicoesQueGanha(corDaMinhaBola);
			int colunaPossivelAdv = analisador.posicoesQueGanha(corAdversario);
			
			if(colunaPossivelJog != -1)
				return colunaPossivelJog;
			if(colunaPossivelAdv != -1)
				return colunaPossivelAdv;
			
			EstadoConnectFour estado = 
							new EstadoConnectFour(tabuleiro, corDaMinhaBola, 0, corAdversario);
			
			return BuscaMinimax.getJogada(estado, 6 );
		} 
		catch(Exception e) {
			System.out.println("Ops.. :(\n " + e.getCause());
			return 0;
		}
	}
	
	public static void main(String[] args)
	{
		CoronelNascimento aspira = new CoronelNascimento();
		
		int[][] teste = new int[][]
		       {
					{ 0, 0, 0, 0, 0, 0, 0 }
				   ,{ 0, 0, 0, 0, 0, 0, 0 }
				   ,{ 0, 0, 2, 1, 0, 0, 0 }
				   ,{ 0, 0, 1, 2, 1, 0, 1 }
				   ,{ 0, 0, 2, 2, 0, 1, 2 }
				   ,{ 0, 0, 1, 2, 0, 1, 2 }
				   ,{ 0, 0, 2, 1, 2, 1, 2 }
		       };
		
		System.out.println("Jogada: " + aspira.jogada(teste, 1));
	}
}
