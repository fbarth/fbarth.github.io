/**
 * @author Adriano T. Tanaka
 * 		   Aline K. Miyazaki
 * 		   Guilherme P. Rey
 */
package linhaQuatro.jogadores.BOPE;

public class BuscaMinimax {

	private static EstadoMinimax melhorEstado;
	
	public static Integer MaisInfinito  =  1000;
	public static Integer MenosInfinito = -1000;
	
	private static double maxValue(EstadoMinimax estado, int profundidade, double alfa, double beta)
	{
		if(profundidade == 0 || estado.isTerminal())
			return estado.avaliar();
		
		for(EstadoMinimax state : estado.sucessores()) {
			double valor = minValue(state, profundidade - 1, alfa, beta);
			
			if(valor > alfa) {
				alfa = valor;
				melhorEstado = state;
			}
			if(alfa >= beta)
				return alfa;
		}
		return alfa;
	}
	
	private static double minValue(EstadoMinimax estado, int profundidade, double alfa, double beta)
	{
		if(profundidade == 0)
			return estado.avaliar();
		
		for(EstadoMinimax state : estado.sucessores()) {
			beta = Math.min(beta, maxValue(state, profundidade - 1, alfa, beta));
			if(beta <= alfa)
				return beta;
		}
		return beta;
	}
	
	public static int getJogada(EstadoMinimax estado, int profundidade){
		maxValue(estado, profundidade, MenosInfinito, MaisInfinito);
		return melhorEstado.decidirJogada();
	}
	
}
