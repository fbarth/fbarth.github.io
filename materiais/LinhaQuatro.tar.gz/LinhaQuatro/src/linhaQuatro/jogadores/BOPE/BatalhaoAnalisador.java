/**
 * @author Adriano T. Tanaka
 * 		   Aline K. Miyazaki
 * 		   Guilherme P. Rey
 */
package linhaQuatro.jogadores.BOPE;

import java.util.ArrayList;

public class BatalhaoAnalisador {
	int[][] tabuleiro;
	
	public BatalhaoAnalisador(int[][] tabuleiro)
	{
		this.tabuleiro = tabuleiro;
	}
	
	public boolean isEmpty()
	{
		int qtde = 0;
		for(int coluna = 0; coluna < tabuleiro.length; coluna++)
			for(int linha = tabuleiro.length - 1; linha >= 0; linha--)
				if(tabuleiro[linha][coluna] == 0)
					qtde++;
		return qtde == 49 || qtde == 48;
	}
	
	public int quantidade(int simbolo)
	{
		int qtde = 0;
		
		for(int coluna = 0; coluna < tabuleiro.length; coluna++)
			for(int linha = tabuleiro.length - 1; linha >= 0; linha--)
				if(tabuleiro[linha][coluna] == simbolo)
					qtde++;
		
		return qtde;
	}
	
	public ArrayList<Integer> ondeJogou(int simbolo)
	{
		ArrayList<Integer> out = new ArrayList<Integer>();
		
		for(int coluna = 0; coluna < tabuleiro.length; coluna++)
			for(int linha = tabuleiro.length - 1; linha >= 0; linha--)
				if(tabuleiro[linha][coluna] == simbolo)
					out.add(coluna);
		
		return out;
	}
	
	/**
	 * Metodo que verifica quais casas sao jogadas validas e retorna uma lista delas
	 * @return
	 */
	public ArrayList<Integer[]> jogadasValidas()
	{
		ArrayList<Integer[]> jogadasValidas = new ArrayList<Integer[]>();
		
		for(int coluna = 0; coluna < tabuleiro.length; coluna++)
			for(int linha = tabuleiro.length - 1; linha >= 0; linha--)
				if(tabuleiro[linha][coluna] == 0) {
					jogadasValidas.add(new Integer[] { linha, coluna });
					break;
				}
		
		return jogadasValidas;
	}
	
	/**
	 * Verifica no tabuleiro dentro das jogadas validas quais que 
	 * o jogador de parametro jog ganha
	 * @param jog
	 * @return Todas as posicoes que se o adversario jogar, o jogador passado por parametro ganha
	*/
	public Integer posicoesQueGanha(int jog)
	{	
		ArrayList<Integer[]> jogadasValidas = jogadasValidas();
		int jogada = -1; 
		
		for (Integer[] candidatos : jogadasValidas) {
			int horizontal = this.verificaHorizontal(jog, true, candidatos[0], candidatos[1]) +
				this.verificaHorizontal(jog, false, candidatos[0], candidatos[1]);
			int vertical = this.verificaVertical(jog, candidatos[0], candidatos[1]);
			int diagonal1 = this.verificaDiagonal1(jog, true, candidatos[0], candidatos[1]) +
				this.verificaDiagonal1(jog, false, candidatos[0], candidatos[1]);
			int diagonal2 = this.verificaDiagonal2(jog, true, candidatos[0], candidatos[1]) +
				this.verificaDiagonal2(jog, false, candidatos[0], candidatos[1]);
			
			if(horizontal >= 3 || vertical >= 3 || diagonal1 >= 3 || diagonal2 >= 3)
				return jogada = candidatos[1];
		
		}
		return jogada;
	}
	
	/**
	 * Verifica se eu sou vencedor do jogo
	 * 
	 * @param simbolo
	 * @return true ou false
	 */
	public boolean vencedor(int simbolo)
	{
		for(int i = this.tabuleiro.length - 1; i >= 0; i--)
			for(int j = 0; j < this.tabuleiro.length; j++)
				if(    verificaHorizontal(simbolo, true, i, j) == 4
					|| verificaHorizontal(simbolo, false, i, j) == 4
					|| verificaDiagonal1 (simbolo, true, i, j) == 4
					|| verificaDiagonal1 (simbolo, false, i, j) == 4
					|| verificaDiagonal2(simbolo,  true, i, j) == 4
					|| verificaDiagonal2(simbolo,  false, i, j) == 4
					|| verificaVertical(simbolo, i, j) == 4)
					return true;
		return false;
	}
	
	/**
	 * Verifica quantas pecas do simbolo estudado, tem seguidos
	 * @param tabuleiro 
	 * @param simbolo - simbolo estudado (jogador ou adversario)
	 * @param linha
	 * @param coluna
	 * @return a quantidade de simbolos seguidos
	 */
	public int verificaHorizontal(int simbolo, boolean direita, int linha, int coluna)
	{
		int contador = 0; 
		int colunaAux = coluna; 
		
		if(direita) {
			//verifica se existe e se sim quantos a direita
			colunaAux ++; 
			while(colunaAux < this.tabuleiro.length &&
				this.tabuleiro[linha][colunaAux] == simbolo) {
				contador ++; 
				colunaAux ++;
			}
		}
		colunaAux = coluna - 1;
		// verifica se existe e se sim quantos a esquerda
		if(!direita) {
			while(colunaAux >= 0 && this.tabuleiro[linha][colunaAux] == simbolo) {
				contador++;
				colunaAux--;
			}
		}
		return contador;
	}
	
	/**
	 * Verifica quantos do determinado simbolo existe seguidos na vertical 
	 * @param tabuleiro
	 * @param simbolo
	 * @param linha
	 * @param coluna
	 * @return a quantidade de simbolos seguidos
	 */
	public int verificaVertical(int simbolo, int linha, int coluna)
	{
		int contador = 0;
		linha ++;
		while(linha < this.tabuleiro.length && this.tabuleiro[linha][coluna] == simbolo)
		{
			contador++;
			linha++; 
		}
		return contador; 
	}
	
	/**
	 * 
	 * @param tabuleiro
	 * @param simbolo
	 * @param linha
	 * @param coluna
	 * @return
	 */
	public int verificaDiagonal1(int simbolo, boolean superior, int linha, int coluna)
	{
		int contador = 0;
		int linhaAux = linha - 1; 
		int colunaAux = coluna + 1;
		if(superior) {
			// verifica direita cima
			while(linhaAux >= 0 &&
					colunaAux < this.tabuleiro.length &&
					this.tabuleiro[linhaAux][colunaAux] == simbolo)
			{
				contador ++; 
				linhaAux --; 
				colunaAux ++; 
			}
		}
		linhaAux = linha + 1; 
		colunaAux = coluna - 1; 
		// verifica esquerda abaixo
		if(!superior) {
			while( linhaAux < this.tabuleiro.length &&
					colunaAux >= 0 &&
					this.tabuleiro[linhaAux][colunaAux] == simbolo)
			{
				contador ++; 
				linhaAux ++; 
				colunaAux --; 
			}
		}
		
		return contador;
	}
	
	/**
	 * 
	 * @param tabuleiro
	 * @param simbolo
	 * @param linha
	 * @param coluna
	 * @return
	 */
	public int verificaDiagonal2(int simbolo, boolean superior, int linha, int coluna)
	{
		int contador = 0; 
		int linhaAux = linha - 1; 
		int colunaAux = coluna - 1;
		
		if(superior) {
			// verifica esquerda acima
			while(linhaAux >= 0 &&
					colunaAux >= 0 &&
					this.tabuleiro[linhaAux][colunaAux] == simbolo)
			{
				contador ++; 
				linhaAux --; 
				colunaAux --; 
			}
		}
		
		linhaAux = linha + 1; 
		colunaAux = coluna + 1; 
		
		if(!superior) {
			// verifica direita abaixo 
			while (linhaAux < this.tabuleiro.length &&
					colunaAux < this.tabuleiro.length &&
					this.tabuleiro[linhaAux][colunaAux] == simbolo)
			{
				contador ++; 
				linhaAux ++; 
				colunaAux ++; 
			}
		}
		return contador;
	}
	
	@Override
	public String toString(){
		StringBuilder resultado = new StringBuilder();
		for(int i = 0; i < 7; i++){
			for(int j = 0; j < 7; j++){
				resultado.append(" | " + this.tabuleiro[i][j]);
			}
			resultado.append(" | " + "\n");
		}
		return resultado.toString();
	}
}
