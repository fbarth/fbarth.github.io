/**
 * @author Adriano T. Tanaka
 * 		   Aline K. Miyazaki
 * 		   Guilherme P. Rey
 */
package linhaQuatro.jogadores.BOPE;

import java.util.ArrayList;

public class EstadoConnectFour 
			implements EstadoMinimax
{
	/**
	 * Atributos
	 */
	private int[][] tabuleiro;
	private int meuSimbolo;
	private int jogada;
	private int jogadorAnterior;
	private BatalhaoAnalisador analisador;
	
	
	Integer[] OrdemDeCriacao = { 3, 4, 2, 1, 5, 0, 6 };

	public boolean isTerminal ()
	{
		if( analisador.vencedor(this.jogadorAnterior) || analisador.vencedor(this.meuSimbolo))
			return true;
		
		int contador = 0;
		for(int i = 0; i < this.tabuleiro.length; i++)
			for(int j = this.tabuleiro.length - 1; j >= 0; j--)
				if(this.tabuleiro[i][j] != 0)
					contador++;
		if(contador == 49)
			return true;
		return false;
	}
	
	public EstadoConnectFour(int[][] tabuleiro, int corDaMinhaBola, int jogada, int jogadorAnterior){
		this.tabuleiro = tabuleiro;
		this.meuSimbolo = corDaMinhaBola;
		this.jogada = jogada;
		this.jogadorAnterior = jogadorAnterior;
		this.analisador = new BatalhaoAnalisador(tabuleiro);
	}
	
	@Override
	public double avaliar() {
		if(this.analisador == null)
			this.analisador = new BatalhaoAnalisador(this.tabuleiro);
		
		//System.out.println(this.analisador.toString());
		
		final int pesoVitoria = 1000;
		final int pesoDerrota = -1000;
		final int peso1peca  = 2;
		final int peso2pecas = 5;
		final int peso3pecas = 7;
		
		int bomPraMim = 0;
		int bomPraEle = 0;
		
		for(int coluna = 0; coluna < tabuleiro.length ; coluna ++) 
		{
			int linha = tabuleiro.length - 1;
			while(linha >= 0 && tabuleiro [linha][coluna] != 0)
			{
				linha--;
			}
			if(linha >= 0 && tabuleiro[linha][coluna] == 0)
			{
				int horizontalDirJog = analisador.verificaHorizontal(meuSimbolo, true,  linha, coluna);
				int horizontalEsqJog = analisador.verificaHorizontal(meuSimbolo, false, linha, coluna);
				int verticalJog 	 = analisador.verificaVertical(meuSimbolo, linha, coluna);
				int diagonal1SupJog  = analisador.verificaDiagonal1(meuSimbolo, true, linha, coluna);
				int diagonal1InfJog  = analisador.verificaDiagonal1(meuSimbolo, false, linha, coluna);
				int diagonal2SupJog  = analisador.verificaDiagonal2(meuSimbolo, true, linha, coluna);
				int diagonal2InfJog  = analisador.verificaDiagonal2(meuSimbolo, false, linha, coluna);
				
				int horizontalJog = horizontalDirJog + horizontalEsqJog;
				int diagonal1Jog = diagonal1InfJog + diagonal1SupJog; 
				int diagonal2Jog = diagonal2InfJog + diagonal2SupJog;
				
				int num = 0;
				if(horizontalJog == 3 || horizontalJog == 4) num++;
				if(verticalJog == 3 ) num++; 
				if(diagonal1Jog == 3 || diagonal1Jog == 4) num++; 
				if(diagonal2Jog == 3 || diagonal2Jog == 4) num++;
				
				bomPraMim += peso3pecas * num;
				
				num = 0;
				if(horizontalJog == 2) num++; 
				if(verticalJog == 2) num++; 
				if(diagonal1Jog == 2) num++; 
				if(diagonal2Jog == 2) num++; 
				
				bomPraMim += peso2pecas * num;
				
				num = 0;
				if(horizontalJog == 1) num++; 
				if(verticalJog == 1) num++; 
				if(diagonal1Jog == 1) num++; 
				if(diagonal2Jog == 1) num++; 
				
				bomPraMim += peso1peca * num;
				
				int horizontalEsqAdv = analisador.verificaHorizontal(jogadorAnterior, false, linha, coluna);
				int horizontalDirAdv = analisador.verificaHorizontal(jogadorAnterior, true, linha, coluna);
				int verticalAdv  = analisador.verificaVertical  (jogadorAnterior, linha, coluna);
				int diagonal1SupAdv  = analisador.verificaDiagonal1 (jogadorAnterior, true, linha, coluna);
				int diagonal1InfAdv  = analisador.verificaDiagonal1 (jogadorAnterior, false, linha, coluna);
				int diagonal2SupAdv  = analisador.verificaDiagonal2 (jogadorAnterior, true, linha, coluna);
				int diagonal2InfAdv  = analisador.verificaDiagonal2 (jogadorAnterior, false, linha, coluna);
				
				int horizontalAdv = horizontalDirAdv + horizontalEsqAdv; 
				int diagonal1Adv = diagonal1InfAdv + diagonal1SupAdv; 
				int diagonal2Adv = diagonal2InfAdv + diagonal2SupAdv; 
				
				num = 0;
				if(horizontalAdv == 3) num++; 
				if(verticalAdv == 3) num++; 
				if(diagonal1Adv == 3) num++; 
				if(diagonal2Adv == 3) num++; 
				
				bomPraEle += peso3pecas * num;
					
				num = 0;
				if(horizontalAdv == 2) num++; 
				if(verticalAdv == 2) num++;
				if(diagonal1Adv == 2) num++; 
				if(diagonal2Adv == 2) num++; 
				
				bomPraEle += peso2pecas * num;
				
				num = 0;
				if(horizontalAdv == 1) num++; 
				if(verticalAdv == 1) num++; 
				if(diagonal1Adv == 1) num++; 
				if(diagonal2Adv == 1) num++;
				
				bomPraEle += peso1peca * num;
			}
		 }
		
		return    (pesoVitoria * (analisador.vencedor(meuSimbolo) ? 1 : 0))
				+ (pesoDerrota * (analisador.vencedor(jogadorAnterior) ? 1 : 0))
				+ (bomPraMim)
				+ (-1 * bomPraEle);
	}

	@Override
	public ArrayList<EstadoMinimax> sucessores() 
	{
		ArrayList<EstadoMinimax> sucessores = new ArrayList<EstadoMinimax>();
		
		for(Integer coluna : OrdemDeCriacao)
			for(int i = 6; i >= 0; i--)
				if(this.tabuleiro[i][coluna] == 0) 
				{
					int[][] tabAux;
					tabAux = copiaTabuleiro(this.tabuleiro);
					tabAux[i][coluna] = this.meuSimbolo;
					
					sucessores.add(
							new EstadoConnectFour(tabAux, this.jogadorAnterior, coluna, this.meuSimbolo));
					break;
				}
		return sucessores;
	}
	
	/**
	 * Cria uma copia de uma matriz de inteiros que representa um tabuleiro
	 * de liga-quatro.
	 * @param tabuleiro
	 * @return A copia da matriz
	 */
	public int[][] copiaTabuleiro(int[][] tabuleiro)
	{
		int[][] aux = new int[tabuleiro.length][tabuleiro.length];
		for(int i = 0; i < tabuleiro.length; i++)
			for(int j = 0; j < tabuleiro.length; j++)
				aux[i][j] = tabuleiro[i][j];
		return aux;
	}

	@Override
	public int decidirJogada() {
		return this.jogada;
	}

	@Override
	public String printTabuleiro() {
		// TODO Auto-generated method stub
		return null;
	}
}
