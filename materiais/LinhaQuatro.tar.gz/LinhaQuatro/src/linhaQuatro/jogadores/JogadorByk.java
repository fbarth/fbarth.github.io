package linhaQuatro.jogadores;


public class JogadorByk implements Jogador{

	int [][] tabuleiro = new int [7][7];
	int [][] tabuleiroRecebido = new int [7][7];
	int meuNumero = 2;
	int numeroOponente = 1;
	int [] jogadas;
	int [] vetorAux;
	int [][] influencia;
	
	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return "Byk";
	}

	@Override
	public int jogada(int[][] tabuleiro, int corDaMinhaBola) {
		influencia = (new Influencia()).getInfluencia();
		vetorAux = new int [7];
		//percorre a matriz para verificar se h� vencendor
		for(int i = 0; i < 7; i++)
			for(int j = 0; j < 7; j++)
				this.tabuleiro[i][j] = tabuleiro[i][j];
		for(int i = 0; i < 7; i++)
			for(int j = 0; j < 7; j++)
				this.tabuleiroRecebido[i][j] = tabuleiro[i][j];
		this.meuNumero = corDaMinhaBola;
		this.numeroOponente = corDaMinhaBola == 1? 2:1;
//		System.out.println(numeroOponente + "  " + meuNumero);
		novaJogada();
		
		int vitoriaIminente = vitoriaIminente(this.tabuleiro);
		  if(vitoriaIminente != -1){
		   return vitoriaIminente;
		  }
		  
		  
		int defesa = defesa(this.tabuleiro); 
		if(defesa != -1){
			return defesa;
		}
		simularJogada();

		int jogadaPensada =jogadaPensada();
//		System.out.println(jogadaPensada);
//		imprimeTabuleiro(tabuleiro);
//		imprimeTabuleiro(this.tabuleiro);
//		imprimeTabuleiro(this.tabuleiroRecebido);
			return jogadaPensada;
	}
	public void novaJogada(){
		jogadas = new int[]{1, 1, 1, 1, 1, 1, 1};
	}
	public void simularJogada(){
		
			int [][] tabuleirox = new int [7][7];
			for(int i = 0; i < 7; i++)
				for(int j = 0; j < 7; j++)
					tabuleirox[i][j] = this.tabuleiro[i][j];
			for(int jogada1 = 0; jogada1 < 7; jogada1++){
				alteraTabuleiro(tabuleirox, jogada1, this.vetorAux);
				int defesaAux = defesa(tabuleirox);
				if(defesaAux != -1 && defesaAux == jogada1){
					jogadas[defesaAux] = -10000;
				}
				for(int jogada2 = 0; jogada2 < 7; jogada2++){
					if(vencedor(tabuleirox)== meuNumero) jogadas[jogada1]++;
					alteraTabuleiro(tabuleirox, jogada2);
					for(int jogada3 = 0; jogada3 < 7; jogada3++){
						alteraTabuleiro(tabuleirox, jogada3);
						if(vencedor(tabuleirox)== meuNumero) jogadas[jogada1]++;
						for(int jogada4 = 0; jogada4 < 7; jogada4++ ){
							alteraTabuleiro(tabuleirox, jogada4);
							if(vencedor(tabuleirox)== meuNumero) jogadas[jogada1]++;
							//imprimeTabuleiro(tabuleirox);
							desalteraTabuleiro(tabuleirox, jogada4);
						}
						desalteraTabuleiro(tabuleirox, jogada3);
					}
					desalteraTabuleiro(tabuleirox, jogada2);
				}
				desalteraTabuleiro(tabuleirox, jogada1);
			}
//			imprimeTabuleiro(tabuleirox);
//			imprimeTabuleiro(this.tabuleiro);
	}
	
	public int vitoriaIminente(int [][] tabuleiroEntrada){
		  int [][] tabuleiro = new int[7][7];
		  for(int i = 0; i < 7; i++)
		   for(int j = 0; j < 7; j++)
		    tabuleiro[i][j] = tabuleiroEntrada[i][j];
		  for(int i=6; i>=0; i--){
		   if(tabuleiro[i][0]==0){
		    tabuleiro[i][0] = meuNumero;
		    if(vencedor(tabuleiro) == meuNumero){
		     return 0;
		    }
		    tabuleiro[i][0] = 0;
		    break;
		   }
		  }
		  for(int i=6; i>=0; i--){
		   if(tabuleiro[i][1]==0){
		    tabuleiro[i][1] = meuNumero;
		    if(vencedor(tabuleiro) == meuNumero){
		     return 1;
		    }
		    tabuleiro[i][1] = 0;
		    break;
		   }
		  }
		  for(int i=6; i>=0; i--){
		   if(tabuleiro[i][2]==0){
		    tabuleiro[i][2] = meuNumero;
		    if(vencedor(tabuleiro) == meuNumero){
		     return 2;
		    }
		    tabuleiro[i][2] = 0;
		    break;
		   }
		  }
		  for(int i=6; i>=0; i--){
		   if(tabuleiro[i][3]==0){
		    tabuleiro[i][3] = meuNumero;
		    if(vencedor(tabuleiro) == meuNumero){
		     return 3;
		    }
		    tabuleiro[i][3] = 0;
		    break;
		   }
		  }
		  for(int i=6; i>=0; i--){
		   if(tabuleiro[i][4]==0){
		    tabuleiro[i][4] = meuNumero;
		    if(vencedor(tabuleiro) == meuNumero){
		     return 4;
		    }
		    tabuleiro[i][4] = 0;
		    break;
		   }
		  }
		  for(int i=6; i>=0; i--){
		   if(tabuleiro[i][5]==0){
		    tabuleiro[i][5] = meuNumero;
		    if(vencedor(tabuleiro) == meuNumero){
		     return 5;
		    }
		    tabuleiro[i][5] = 0;
		    break;
		   }
		  }
		  for(int i=6; i>=0; i--){
		   if(tabuleiro[i][6]==0){
		    tabuleiro[i][6] = meuNumero;
		    if(vencedor(tabuleiro) == meuNumero){
		     return 6;
		    }
		    tabuleiro[i][6] = 0;
		    break;
		   }
		  }
		  return -1;
		  
		 }
	/*
	 * Verifica se h� alguma necessidade extrema para fazer a jogada
	 */
	public int defesa(int [][] tabuleiroEntrada){
		int [][] tabuleiro = new int[7][7];
		for(int i = 0; i < 7; i++)
			for(int j = 0; j < 7; j++)
				tabuleiro[i][j] = tabuleiroEntrada[i][j];
		for(int i=6; i>=0; i--){
			if(tabuleiro[i][0]==0){
				tabuleiro[i][0] = numeroOponente;
				if(vencedor(tabuleiro) == numeroOponente){
					return 0;
				}
				tabuleiro[i][0] = 0;
				break;
			}
		}
		for(int i=6; i>=0; i--){
			if(tabuleiro[i][1]==0){
				tabuleiro[i][1] = numeroOponente;
				if(vencedor(tabuleiro) == numeroOponente){
					return 1;
				}
				tabuleiro[i][1] = 0;
				break;
			}
		}
		for(int i=6; i>=0; i--){
			if(tabuleiro[i][2]==0){
				tabuleiro[i][2] = numeroOponente;
				if(vencedor(tabuleiro) == numeroOponente){
					return 2;
				}
				tabuleiro[i][2] = 0;
				break;
			}
		}
		for(int i=6; i>=0; i--){
			if(tabuleiro[i][3]==0){
				tabuleiro[i][3] = numeroOponente;
				if(vencedor(tabuleiro) == numeroOponente){
					return 3;
				}
				tabuleiro[i][3] = 0;
				break;
			}
		}
		for(int i=6; i>=0; i--){
			if(tabuleiro[i][4]==0){
				tabuleiro[i][4] = numeroOponente;
				if(vencedor(tabuleiro) == numeroOponente){
					return 4;
				}
				tabuleiro[i][4] = 0;
				break;
			}
		}
		for(int i=6; i>=0; i--){
			if(tabuleiro[i][5]==0){
				tabuleiro[i][5] = numeroOponente;
				if(vencedor(tabuleiro) == numeroOponente){
					return 5;
				}
				tabuleiro[i][5] = 0;
				break;
			}
		}
		for(int i=6; i>=0; i--){
			if(tabuleiro[i][6]==0){
				tabuleiro[i][6] = numeroOponente;
				if(vencedor(tabuleiro) == numeroOponente){
					return 6;
				}
				tabuleiro[i][6] = 0;
				break;
			}
		}
		return -1;
		
	}
	/*
	 * recebe um tabuleiro e verifica se ha ganhador, se sim retorna o numero de tal.
	 */
	public int vencedor(int [][] tabuleiro){
		for(int i = 0 ; i < 7; i ++){
			for(int j = 0; j < 7; j++){
				int local = tabuleiro[i][j];
				int ii, jj, cont;
				cont = 0;
				ii = i;
				jj = j;
				while((tabuleiro[ii][jj] != 0 && tabuleiro[ii][jj] == local) ||( ii >=4 && cont == 0)){
					cont++;
					if(cont == 4){
						return local;
					}
					ii++;
					if(ii >= 7)
						break;
				}
				cont = 0;
				ii = i;
				jj = j;
				while((tabuleiro[ii][jj] != 0 && tabuleiro[ii][jj] == local) ||( jj >=4 && cont == 0)){
					cont++;
					if(cont == 4){
						return local;
					}
					jj++;
					if(jj >= 7)
						break;
				}
				cont = 0;
				ii = i;
				jj = j;
				while((tabuleiro[ii][jj] != 0 && tabuleiro[ii][jj] == local) ||( ii >=4 && jj>=4 && cont == 0)){
					cont++;
					if(cont == 4){
						return local;
					}
					jj++;
					ii++;
					if(ii >= 7 || jj >=7)
						break;
				}
				cont = 0;
				ii = i;
				jj = j;
				while((tabuleiro[ii][jj] != 0 && tabuleiro[ii][jj] == local )){
					cont++;
					if(cont == 4){
						return local;
					}
					jj++;
					ii--;
					if(ii < 0  || jj>= 7 )
						break;
				}
			}
		}
		return -1;
	}
	
	public int alteraTabuleiro(int [][]tabuleiro,int jogada){
		for(int i=6; i>=0; i--){
			if(tabuleiro[i][jogada]==0){
				tabuleiro[i][jogada] = meuNumero;
				return i;
			}
		}
		return -1;
	}
	public void alteraTabuleiro(int [][]tabuleiro,int jogada, int[] vetorAux){
		for(int i=6; i>=0; i--){
			if(tabuleiro[i][jogada]==0){
				tabuleiro[i][jogada] = meuNumero;
				vetorAux[jogada] = i;
				return;
			}
		}
	}
	public void desalteraTabuleiro(int [][]tabuleiro,int jogada){
		for(int i=6; i>=0; i--){
			if(i == 0 && tabuleiro[i][jogada]!=0 && this.tabuleiro[i][jogada] == 0){
				tabuleiro[i][jogada] = 0;
				return;
			}
			if(tabuleiro[i][jogada]==0){
				if(this.tabuleiro[i+1][jogada] == 0)
					tabuleiro[i+1][jogada] = 0;
				return;
			}
		}
	}
	
	public int jogadaPensada(){
		int jogada = 0;
		for(int i = 0; i < 7; i++){
			if(this.tabuleiroRecebido[0][i] == 0){
				jogada = i;	
				break;
			}
		}
//		for(int i = 6; i > 0 ; i--){
//			for(int j = 0; j < 7; j++){
//				if(this.tabuleiroRecebido[i][j] == 0){
//					if(jogadas[jogada]*influencia[i][j] < jogadas[i]*influencia[i][j]){
//						jogada = i;
//					}
//				}
//			}
//		}
		for(int j = 0; j < 7; j++){
			for(int i = 6; i > 0; i--){
				if(this.tabuleiroRecebido[i][j] == 0){
					if(jogadas[jogada]*influencia[i][j] < jogadas[i]*influencia[i][j]){
						jogada = i;
					}
				}
			}
		}
		return jogada;
	}
	public void imprimeTabuleiro(int [][]tabuleiro){
		String imprime = "";
		for(int i = 0; i < 7 ; i ++){
			for(int j = 0; j < 7; j++)
				imprime += tabuleiro[i][j] + " ";
			imprime += "\n";	
		}
		System.out.println(imprime);
	}

}

class Influencia{
	
	int [][] influencia = {{3,  4,  5,  7,  5,  4, 3},
			   {4,  5,  6,  8,  6,  5, 4}, 
			   {5,  6,  9, 13,  9,  6, 5},
			   {7,  8, 13, 16, 13,  8, 7},
			   {5,  6,  9, 13,  9,  6, 5},
			   {4,  5,  6,  8,  6,  5, 4}, 
			   {3,  4,  5,  7,  5,  4, 3}};

	public int[][] getInfluencia() {
		return influencia;
	}

	public void setInfluencia(int[][] influencia) {
		this.influencia = influencia;
	}
	
	
	
}




