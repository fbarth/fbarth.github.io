package linhaQuatro.jogadores;

import java.util.ArrayList;

/**
 * Estado da classe do JogadorGanhaNada
 *
 * @author Erick S. Miyazaki / Bruno Sa / Fernando Divanor
 */
public class EstadoMinMaxAlphaBetaGanhaNada implements EstadoUtilidade
{
    private int[][] tabuleiro;
    private int corDaMinhaBola, corDoOponente;
    private int jogada;
    private int jogadorAnterior;

    public EstadoMinMaxAlphaBetaGanhaNada(int[][] tabuleiro, int corDaMinhaBola, int jogada, int jogadorAnterior)
    {
        this.tabuleiro = tabuleiro;
	this.corDaMinhaBola = corDaMinhaBola;
	this.jogada = jogada;
	this.jogadorAnterior = jogadorAnterior;
        if (corDaMinhaBola == 1)
        {
            this.corDoOponente = 2;
        }
        else
        {
            this.corDoOponente = 1;
        }
    }

    @Override
    public double eval()
    {
	int vitoria = 10000;
	int derrota =-10000;
	int p2 = 10;
	int p3 = 50;

	return (vitoria * euGanho()) + (derrota * oponenteGanha())+
               (p2 * possibilidadeVitoriaMinhaComDuasPecas())+
               (-1 * p2 * possibilidadeVitoriaOponenteComDuasPecas())+
               (p3 * possibilidadeVitoriaMinhaComUmaPeca())+
               (-1 * p3 * possibilidadeVitoriaOponenteComUmaPeca());
    }

    private int euGanho()
    {
	for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 7; j++)
            {
                if (this.tabuleiro[i][j] == this.corDaMinhaBola)
                {
                    if (verifica4Peças(i,j) == true)
                    {
                        return 1;
                    }
                }
            }
	}
        return 0;
    }

    private int oponenteGanha()
    {
	for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 7; j++)
            {
                if (this.tabuleiro[i][j] == this.corDoOponente)
                {
                    if (verifica4Peças(i,j) == true)
                    {
                        return 1;
                    }
                }
            }
	}
        return 0;
    }

    private int possibilidadeVitoriaOponenteComUmaPeca()
    {
	int cont = 0;
	for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 7; j++)
            {
                if (this.tabuleiro[i][j] == this.corDoOponente)
                {
                    cont = cont + verifica3Peças(i, j, this.corDoOponente);
                }
            }
	}
	return cont;
    }

    private int possibilidadeVitoriaMinhaComUmaPeca()
    {
	int cont = 0;
	for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 7; j++)
            {
                if (this.tabuleiro[i][j] == this.corDaMinhaBola)
                {
                    cont = cont + verifica3Peças(i, j, this.corDaMinhaBola);
                }
            }
	}
	return cont;
    }

    private int possibilidadeVitoriaOponenteComDuasPecas()
    {
	int cont = 0;
	for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 7; j++)
            {
		if (this.tabuleiro[i][j] == this.corDoOponente)
                {
                    cont = cont + verifica2Peças(i, j, this.corDoOponente);
		}
            }
	}
        return cont;
    }

    private int possibilidadeVitoriaMinhaComDuasPecas()
    {

        int cont = 0;
        for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 7; j++)
            {
		if (this.tabuleiro[i][j] == this.corDaMinhaBola)
                {
                    cont = cont + verifica2Peças(i, j, this.corDaMinhaBola);
		}
            }
        }
	return cont;
    }

    private boolean verifica4Peças(int i, int j)
    {
        //Checando a horizontal.
        if (j <= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i][j+1] &&
                this.tabuleiro[i][j] == this.tabuleiro[i][j+2] &&
                this.tabuleiro[i][j] == this.tabuleiro[i][j+3])
            {
                return true;
            }
        }

        //Checando a vertifical.
        if (i <= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i+1][j] &&
                this.tabuleiro[i][j] == this.tabuleiro[i+2][j] &&
                this.tabuleiro[i][j] == this.tabuleiro[i+3][j])
            {
                return true;
            }
	}

        //Verifica diagonal /.
        if (i <= 3 && j >= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i+1][j-1] &&
                this.tabuleiro[i][j] == this.tabuleiro[i+2][j-2] &&
                this.tabuleiro[i][j] == this.tabuleiro[i+3][j-3])
            {
                return true;
            }
        }

        //Verifica diagonal \.
        if (i <= 3 && j <= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i+1][j+1] &&
                this.tabuleiro[i][j] == this.tabuleiro[i+2][j+2] &&
                this.tabuleiro[i][j] == this.tabuleiro[i+3][j+3])
            {
                return true;
            }
        }
        return false;
    }

    private int verifica3Peças(int i, int j, int cor)
    {
        int valor = 0;

        //Checando a horizontal.
        if (j <= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i][j+1] &&
                this.tabuleiro[i][j] == this.tabuleiro[i][j+2])
            {
                valor = valor + 25;
            }
            else
            {
                for (int y = 1; i < 3; i++)
                {
                    if (this.tabuleiro[i][j+y] == 0)
                    {
                        valor = valor + 15;
                    }
                    else if (cor == this.corDaMinhaBola)
                    {
                        if (this.tabuleiro[i][j+y] == this.corDoOponente)
                        {
                            valor = valor - 15;
                            break;
                        }
                    }
                    else if (cor == this.corDoOponente)
                    {
                        if (this.tabuleiro[i][j+y] == this.corDaMinhaBola)
                        {
                            valor = valor - 15;
                            break;
                        }
                    }
                }
            }
        }
        
        //Checando a vertifical.
        if (i <= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i+1][j] &&
                this.tabuleiro[i][j] == this.tabuleiro[i+2][j])
            {
		valor = valor + 25;
            }
            else
            {
                for (int y = 1; i < 3; i++)
                {
                    if (this.tabuleiro[i+y][j] == 0)
                    {
                        valor = valor + 15;
                    }
                    else if (cor == this.corDaMinhaBola)
                    {
                        if (this.tabuleiro[i+y][j] == this.corDoOponente)
                        {
                            valor = valor - 15;
                            break;
                        }
                    }
                    else if (cor == this.corDoOponente)
                    {
                        if (this.tabuleiro[i+y][j] == this.corDaMinhaBola)
                        {
                            valor = valor - 15;
                            break;
                        }
                    }
                }
            }
        }
        

        //Verifica diagonal /.
        if (i <= 3 && j >= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i+1][j-1] &&
                this.tabuleiro[i][j] == this.tabuleiro[i+2][j-2])
            {
		valor = valor + 50; //Dou mais preferencia para jogadas na diagonal.
            }
            else
            {
                for (int y = 1; i < 3; i++)
                {
                    if (this.tabuleiro[i+y][j-y] == 0)
                    {
                        valor = valor + 15;
                    }
                    else if (cor == this.corDaMinhaBola)
                    {
                        if (this.tabuleiro[i+y][j-y] == this.corDoOponente)
                        {
                            valor = valor - 15;
                            break;
                        }
                    }
                    else if (cor == this.corDoOponente)
                    {
                        if (this.tabuleiro[i+y][j-y] == this.corDaMinhaBola)
                        {
                            valor = valor - 15;
                            break;
                        }
                    }
                }
            }
        }

        //Verifica diagonal \.
        if (i <= 3 && j <= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i+1][j+1] &&
                this.tabuleiro[i][j] == this.tabuleiro[i+2][j+2])
            {
		valor = valor + 50; //Dou mais preferencia para jogadas na diagonal.
            }
            else
            {
                for (int y = 1; i < 3; i++)
                {
                    if (this.tabuleiro[i+y][j+y] == 0)
                    {
                        valor = valor + 15;
                    }
                    else if (cor == this.corDaMinhaBola)
                    {
                        if (this.tabuleiro[i+y][j+y] == this.corDoOponente)
                        {
                            valor = valor - 15;
                            break;
                        }
                    }
                    else if (cor == this.corDoOponente)
                    {
                        if (this.tabuleiro[i+y][j+y] == this.corDaMinhaBola)
                        {
                            valor = valor - 15;
                            break;
                        }
                    }
                }
            }
        }
        return valor;
    }

    private int verifica2Peças(int i, int j, int cor)
    {
        int valor = 0;

        //Checando a horizontal.
        if (j <= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i][j+1])
            {
                valor = valor + 5;
            }
            else if (this.tabuleiro[i][j+1] == 0)
            {
                valor = valor + 2;
            }
            else if (cor == this.corDaMinhaBola)
            {
                if (this.tabuleiro[i][j+1] == this.corDoOponente)
                {
                    valor = valor - 2;
                }
            }
            else if (cor == this.corDoOponente)
            {
                if (this.tabuleiro[i][j+1] == this.corDaMinhaBola )
                {
                    valor = valor - 2;
                }
            }
        }

        //Checando a vertifical
        if (i <= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i+1][j])
            {
		valor = valor + 5;
            }
            else if (this.tabuleiro[i+1][j] == 0)
            {
                valor = valor + 2;
            }
            else if (cor == this.corDaMinhaBola)
            {
                if (this.tabuleiro[i+1][j] == this.corDoOponente)
                {
                    valor = valor - 2;
                }
            }
            else if (cor == this.corDoOponente)
            {
                if (this.tabuleiro[i+1][j] == this.corDaMinhaBola )
                {
                    valor = valor - 2;
                }
            }
        }

        //Verifica diagonal /.
        if (i <= 3 && j >= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i+1][j-1])
            {
		valor = valor + 8; //Dou mais valor as diagonais
            }
            else if (this.tabuleiro[i+1][j-1] == 0)
            {
                valor = valor + 2;
            }
            else if (cor == this.corDaMinhaBola)
            {
                if (this.tabuleiro[i+1][j-1] == this.corDoOponente)
                {
                    valor = valor - 2;
                }
            }
            else if (cor == this.corDoOponente)
            {
                if (this.tabuleiro[i+1][j-1] == this.corDaMinhaBola )
                {
                    valor = valor - 2;
                }
            }
        }
        //Verifica diagonal \.
        if (i <= 3 && j <= 3)
        {
            if (this.tabuleiro[i][j] == this.tabuleiro[i+1][j+1])
            {
		valor = valor + 8; //Dou mais valor as diagonais.
            }
            else if (this.tabuleiro[i+1][j+1] == 0)
            {
                valor = valor + 2;
            }
            else if (cor == this.corDaMinhaBola)
            {
                if (this.tabuleiro[i+1][j+1] == this.corDoOponente)
                {
                    valor = valor - 2;
                }
            }
            else if (cor == this.corDoOponente)
            {
                if (this.tabuleiro[i+1][j+1] == this.corDaMinhaBola )
                {
                    valor = valor - 2;
                }
            }
        }
        return valor;
    }

    @Override
    public int getJogada()
    {
	return this.jogada;
    }

    @Override
    public ArrayList<EstadoUtilidade> sucessors()
    {
        ArrayList<EstadoUtilidade> sucessores = new ArrayList<EstadoUtilidade>();
	for (int opcoesDejogada = 0; opcoesDejogada <= 6; opcoesDejogada++)
        {
            if (this.tabuleiro[0][opcoesDejogada] != 0)
            {
                continue;
            }
            for (int i = 6; i >= 0; i--)
            {
		if (this.tabuleiro[i][opcoesDejogada] == 0)
                {
                    int[][] tabuleiroTemp;
                    tabuleiroTemp = transfereValores(this.tabuleiro);
                    tabuleiroTemp[i][opcoesDejogada]=this.corDaMinhaBola;
                    if (this.jogadorAnterior == 1)
                    {
			tabuleiroTemp[i][opcoesDejogada] = 2;
			sucessores.add(new EstadoMinMaxAlphaBetaGanhaNada(tabuleiroTemp, this.corDaMinhaBola, opcoesDejogada, 2));
                    }
                    else
                    {
			tabuleiroTemp[i][opcoesDejogada] = 1;
                        sucessores.add(new EstadoMinMaxAlphaBetaGanhaNada(tabuleiroTemp, this.corDaMinhaBola, opcoesDejogada, 1));
                    }
                        break;
		}
            }
	}
	return sucessores;
    }

    private int[][] transfereValores(int[][] in)
    {
        int[][] out = new int[7][7];
	for(int i=0; i<7; i++)
        {
            for(int j=0; j<7; j++)
            {
		out[i][j] = in[i][j];
            }
	}
	return out;
    }

    /**
     * Eh utilizado apenas para debug.
     */
    public String printTabuleiro()
    {
	String resultado = "";
	for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 7; j++)
            {
		resultado = resultado + " | "+this.tabuleiro[i][j];
            }
            resultado = resultado + " | " + "\n";
	}
	return resultado;
    }
}

