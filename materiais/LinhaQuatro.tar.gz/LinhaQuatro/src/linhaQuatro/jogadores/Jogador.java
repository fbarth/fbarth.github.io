package linhaQuatro.jogadores;

/**
 * Interface respons�vel por definir os m�todos que
 * devem ser implementados pelos jogadores.
 * 
 * @author Fabr�cio J. Barth
 * @version 05, novembro, 2007
 *
 */
public interface Jogador {
	
	public String getNome();
	
	public int jogada(int[][] tabuleiro, int corDaMinhaBola);

}
