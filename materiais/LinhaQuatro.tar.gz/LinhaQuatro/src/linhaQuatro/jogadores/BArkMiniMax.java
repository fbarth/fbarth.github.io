package linhaQuatro.jogadores;

import java.util.ArrayList;

public class BArkMiniMax{
	private static BArkMiniMaxEstado melhorJogada;
	
	private static double maxValue(BArkMiniMaxEstado jogo, int profundidade){
		if(profundidade==0){
			//System.out.println("");
			//System.out.println("");
			//System.out.println("Tabuleiro = "+estado.printTabuleiro());
			//System.out.println("Jogada = "+estado.getJogada());
			//System.out.println("Avalia��o = "+estado.eval());
			return jogo.eval();
		}
		double v = -10000; //infinito negativo
		profundidade = profundidade - 1;
		ArrayList <BArkMiniMaxEstado> s = jogo.sucessors();
		for(int i = 0; i < s.size(); i++){
			double valor = minValue(s.get(i),profundidade);
			if(valor > v){
				v = valor;
				melhorJogada = s.get(i);
			}
		}
		return v;
	}
	
	private static double minValue(BArkMiniMaxEstado jogo, int profundidade){
		if(profundidade==0){
			return jogo.eval();
		}
		double v = 10000; //infinito positivo
		profundidade = profundidade - 1;
		ArrayList<BArkMiniMaxEstado> s = jogo.sucessors();
		for(int i=0; i<s.size(); i++){
			v = Math.min(v, maxValue(s.get(i),profundidade));
		}
		return v;
	}
	
	/**
	 * A fun��o deste m�todo � retornar a opera��o
	 * que o jogador deve efetuar.
	 * 
	 * @return
	 */
	public static int getJogada(BArkMiniMaxEstado jogo, int profundidade){
		maxValue(jogo,profundidade);
		return melhorJogada.getJogada();
	}
}
