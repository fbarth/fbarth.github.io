package linhaQuatro.jogadores;

/**
 * -------------------------------------------------------
 * MÉTODO looseInNextTurn() RETIRADO DO JOGADOR Paquiderme
 * -------------------------------------------------------
 * 
 * Projeto P2 - Competição de quatro em uma linha
 * Bacharelado em Ciência da Computação
 * Laboratório de Programação IV - IA
 * Alunos: Alexander, Leidiane e Luiz Paulo
 * Jogador: Tio da Pipoca
 */
public class TioDaPipoca implements Jogador {

    /**
     * Profundidade adoada pela equipe para a busca
     * OBS: PODE SER ALTERADA PARA SE ADAPTAR AO COMPUTADOR QUE RODA O JOGO
     */
    public int Profundidade = 6;

    /**
     * Método que retorna o nome do jogador
     * @return String
     */
    public String getNome() {
        return "Tio da Pipoca";
    }

    /**
     * Método principal da classe, responsável por passar a jogada ao controlador dos jogos
     * @param tabuleiro
     * @param corDaMinhaBola
     * @return int
     */
    public int jogada(int[][] tabuleiro, int corDaMinhaBola) {

        int adiversario = 0;
        if (corDaMinhaBola == 1) {
            adiversario = 2;
        } else {
            adiversario = 1;        //Caso a próxima jogada eu ganho, retorna a coluna para a vitória !!!!
        }
        if (looseInNextTurn(copiaTabuleiro(tabuleiro), corDaMinhaBola, adiversario) != -1) {
            int play = looseInNextTurn(tabuleiro, corDaMinhaBola, adiversario);
            return play;
        }

        //Caso a próxima jogada meu adiversário ganaha, jogo onde ele IRIA ganhar !!!!
        if (looseInNextTurn(copiaTabuleiro(tabuleiro), adiversario, corDaMinhaBola) != -1) {
            int play = looseInNextTurn(tabuleiro, adiversario, corDaMinhaBola);
            return play;
        }

        // Caso nenhuma das opções acima...
        try {
            EstadoTioDaPipoca estado;
            if (corDaMinhaBola == 1) {
                estado = new EstadoTioDaPipoca(tabuleiro, corDaMinhaBola, 3, 2);
            } else {
                estado = new EstadoTioDaPipoca(tabuleiro, corDaMinhaBola, 3, 1);
            }
            return MinMaxTioDaPipoca.getJogada(estado, Profundidade);
        } catch (Exception e) {
            return proximoColunaVazia(copiaTabuleiro(tabuleiro));
        }
    }

    /**
     * Método que retorna a próxima coluna possível para uma jogada.
     * @param tabuleiro
     * @return int
     */
    public int proximoColunaVazia(int[][] tabuleiro) {
        for (int i = 0; i < 7; i++) {
            if (tabuleiro[6][i] == 0) {
                return i;
            }
        }

        // retorno padrao da função, esperamos que não ocorra
        return 3;
    }

    /**
     * Método que faz uma cópia do tabuleiro, para retirar os erros de referência
     * @param tabuleiro
     * @return int[][]
     */
    public static int[][] copiaTabuleiro(int[][] tabuleiro) {
        int[][] copia = new int[tabuleiro.length][tabuleiro[0].length];
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                copia[i][j] = tabuleiro[i][j];
            }
        }

        return copia;
    }

    /**
     * Método que verifica, dependendo dos parametros passados, quem ganhará na próxima rodada
     * @param tabuleiro
     * @param corDaMinhaBola
     * @param corBolaInimigo
     * @return int
     */
    public int looseInNextTurn(int[][] tabuleiro, int corDaMinhaBola, int corBolaInimigo) {
        int enemyWinFlag = 0;
        int dangerLine = -1;
        //Verifies if enemy will win in any place in the next play.
        //Vertical
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (tabuleiro[j][i] == corBolaInimigo) {
                    enemyWinFlag++;
                    if (enemyWinFlag == 3) {
                        if (j >= 3 && tabuleiro[j - 3][i] == 0) {
                            dangerLine = i;
                            return dangerLine;
                        } else {
                            if (j == 2 && tabuleiro[j - 2][i] == 0) {
                                dangerLine = i;
                                return dangerLine;
                            }
                        }
                    }
                } else {
                    enemyWinFlag = 0;
                }
            }
        }
        //Horizontal
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (tabuleiro[i][j] == corBolaInimigo) {
                    enemyWinFlag++;
                    if (enemyWinFlag == 3) {
                        if (j < 6 && tabuleiro[i][j + 1] == 0) {
                            dangerLine = j + 1;
                            return dangerLine;
                        }
                        if (j > 3 && tabuleiro[i][j - 3] == 0) {
                            dangerLine = j - 3;
                            return dangerLine;
                        }
                    }
                } else {
                    enemyWinFlag = 0;
                }
            }
        }

        return dangerLine;
    }
}
