package linhaQuatro.jogadores;

import java.util.ArrayList;

/**
 * Classe que faz a busca utilizando o algoritmo Min-Max Alpha Beta.
 *
 * @author Erick S. Miyazaki / Bruno Sa / Fernando Divanor
 */

public class MinMaxAlphaBetaGanhaNada
{
    private static EstadoUtilidade maiorEstado;
    
    private static double maxValue(EstadoUtilidade estado, double alpha, double beta, int profundidade)
    {
        if (profundidade == 0)
        {
            double a = estado.eval();
            return a;
	}
        ArrayList<EstadoUtilidade> s = estado.sucessors();
        if (s.size() == 0)//Prevenir tabuleiro cheio.
        {
            System.out.println (estado.eval());
            return estado.eval();
        }
        for (int i = 0; i < s.size(); i++)
        {
            double valor = Math.max (alpha, minValue (s.get(i), alpha, beta, profundidade-1));
            if (valor >= beta)
            {
                return beta;
            }
            if (valor > alpha)
            {
                if (profundidade == 7)
                {
                    maiorEstado = s.get(i);
                }
                alpha = valor;
            }
	}
	return alpha;
    }
    
    private static double minValue(EstadoUtilidade estado, double alpha, double beta, int profundidade)
    {
        if (profundidade == 0)
        {
            return estado.eval();
	}
	ArrayList<EstadoUtilidade> s = estado.sucessors();
        if (s.size() == 0) //Prevenir tabuleiro cheio.
        {
            return 0;
        }
	for (int i = 0; i < s.size(); i++)
        {
            double valor = Math.min (beta, maxValue (s.get(i), alpha, beta, profundidade-1));
            if ( valor <= alpha )
            {
		return alpha;
            }
            if( valor < beta )
            {
                beta = valor;
            }
	}
	return beta;
    }

    public static int getJogada(EstadoUtilidade estado, int profundidade)
    {
        double a = maxValue (estado, -100000, 100000, profundidade);
        System.out.println ("Valor do eval: " + a);
	return maiorEstado.getJogada();
    }
}
