package linhaQuatro.jogadores;

import java.util.ArrayList;

public interface EstadoUtilidade
    {
        public double eval();
	public ArrayList<EstadoUtilidade> sucessors();
	public int getJogada();
    }