package linhaQuatro.jogadores;

public class JogadorManolo implements Jogador {
	private int[][] tabuleiro;
	private int cor;
	private int adversario;
	
	@Override
	public int jogada( int[][] tabuleiro, int cor ) {
		this.tabuleiro = tabuleiro;
		this.cor = cor;
		this.adversario = ( cor % 2 ) + 1;
		
		int melhor_coluna = this.getMelhorJogadaMinMax();
		
		//System.out.println( "Manolo joga na coluna " + melhor_coluna );
		return melhor_coluna;
	}

	private int getMelhorJogadaMinMax() {
		int jogadasPossiveis[][] = this.getJogadasPossiveis();

		// vamos verificar se existe alguma coluna que garante a vitoria
		// nesse caso jogamos diretamente
		for( int i = 0; i < jogadasPossiveis.length; i++ )
		{
			int utilidade = this.getUtilidade( jogadasPossiveis[i][0], jogadasPossiveis[i][1] );
			if( utilidade > 50 )
			{
				return i;
			}
			// mesma coisa para o adversario
			utilidade = this.getUtilidadeAdversario( jogadasPossiveis[i][0], jogadasPossiveis[i][1] );
			if( utilidade > 50 )
			{
				return i;
			}
		}
		
		// quantos niveis vamos descer
		int niveis = 3;
		int[] resultado = this.getMelhorJogadaMax( niveis );
		
		return resultado[0];
	}
	
	private int[] getMelhorJogadaMax( int nivel ) {
		// sao tabuleiro.length as jogadas possiveis
		// vamos simular jogadas para todas as posicoes em volta dos locais validos pra se jogar a peca
		int jogadasPossiveis[][] = this.getJogadasPossiveis();

		// calculo da utilidade de cada uma das jogadas possiveis
		int max = -5000;
		int melhor_coluna = -1;
		for( int i = 0; i < jogadasPossiveis.length; i++ )
		{
			if( nivel - 1 > 0 )
			{
				int linha = jogadasPossiveis[i][0];
				int coluna = jogadasPossiveis[i][1];
				if( linha < 0 )
				{
					continue;
				}
				
				// se a utilidade desta jogada sera uma vitoria, vamos usar ela
				int utilidade = this.getUtilidade( linha, coluna );
				if( utilidade > 50 )
				{
					melhor_coluna = i;
					max = Math.max( max, utilidade );
					break;
				}
				
				this.tabuleiro[linha][coluna] = this.cor;
				this.inverteJogadores();
				
				int[] resultado = this.getMelhorJogadaMin( nivel - 1 );
				if( melhor_coluna == -1 || resultado[1] > max )
				{
					melhor_coluna = i;
				}
				// prioridade pra coluna do meio
				if( resultado[1] == max && i == 3 )
				{
					melhor_coluna = i;
				}
				max = Math.max( max, resultado[1] );
				// System.out.printf( "MAX (na coluna %d) %d\n", coluna, max );

				// desfaz a simulacao da peca naquele local e inverte novamente os jogadores
				this.inverteJogadores();
				this.tabuleiro[linha][coluna] = 0;	
			}
			else
			{
				int utilidade = this.getUtilidade( jogadasPossiveis[i][0], jogadasPossiveis[i][1] );
				// System.out.printf( "[MAX] Utilidade para a coluna %d: %d\n", i, utilidade );
				if( melhor_coluna == -1 || utilidade > max )
				{
					melhor_coluna = i;
				}
				// prioridade pra coluna do meio
				if( utilidade == max && i == 3 )
				{
					melhor_coluna = i;
				}
				max = Math.max( max, utilidade );
			}
		}

		// System.out.printf( "Retorno (nivel, coluna, max): %d, %d, %d\n", nivel - 1, melhor_coluna, max );
		int[] retorno = new int[]{ melhor_coluna, max };
		return retorno;
	}
	
	private int[] getMelhorJogadaMin( int nivel ) {
		// sao tabuleiro.length as jogadas possiveis
		// vamos simular jogadas para todas as posicoes em volta dos locais validos pra se jogar a peca
		int jogadasPossiveis[][] = this.getJogadasPossiveis();

		// calculo da utilidade de cada uma das jogadas possiveis
		int min = 5000;
		int melhor_coluna = -1;
		for( int i = 0; i < jogadasPossiveis.length; i++ )
		{
			if( nivel - 1 > 0 )
			{
				int linha = jogadasPossiveis[i][0];
				int coluna = jogadasPossiveis[i][1];
				if( linha < 0 )
				{
					continue;
				}
				
				// se a utilidade desta jogada sera uma vitoria (ou derrota), vamos usar ela
				int utilidade = this.getUtilidade( linha, coluna );
				if( utilidade > 50 )
				{
					melhor_coluna = i;
					min = Math.min( min, utilidade );
					break;
				}
				
				this.tabuleiro[linha][coluna] = this.cor;
				this.inverteJogadores();
				
				int[] resultado = this.getMelhorJogadaMax( nivel - 1 );
				// System.out.printf( "coluna: %d, max: %d\n", resultado[0], resultado[1] );
				if( melhor_coluna == -1 || resultado[1] < min )
				{
					melhor_coluna = i;
				}
				// prioridade pra coluna do meio
				if( resultado[1] == min && i == 3 )
				{
					melhor_coluna = i;
				}
				min = Math.min( min, resultado[1] );
				// System.out.printf( "MIN (na coluna %d) %d\n", coluna, min );

				// desfaz a simulacao da peca naquele local e inverte novamente os jogadores
				this.inverteJogadores();
				this.tabuleiro[linha][coluna] = 0;	
			}
			else
			{
				int utilidade = this.getUtilidade( jogadasPossiveis[i][0], jogadasPossiveis[i][1] );
				// System.out.printf( "  [min] Utilidade para a coluna %d: %d\n", i, utilidade );
				if( melhor_coluna == -1 || utilidade < min )
				{
					melhor_coluna = i;
				}
				// prioridade pra coluna do meio
				if( utilidade == min && i == 3 )
				{
					melhor_coluna = i;
				}
				min = Math.min( min, utilidade );
			}
		}
		
		// System.out.printf( "Retorno (nivel, coluna, min): %d, %d, %d\n", nivel - 1, melhor_coluna, min );
		int[] retorno = new int[]{ melhor_coluna, min };
		return retorno;
	}

	private int getUtilidade( int linha, int coluna ) {
		// System.out.println( "calculando jogada na coluna: " + coluna );
		
		return
			this.getUtilidadeHorizontal( linha, coluna ) +
			this.getUtilidadeVertical( linha, coluna ) + 
			this.getUtilidadeDiagonalCrescente( linha, coluna ) + 
			this.getUtilidadeDiagonalDecrescente( linha, coluna );
	}

	private int getUtilidadeAdversario( int linha, int coluna ) {
		this.inverteJogadores();
		
		int utilidade = this.getUtilidadeHorizontal( linha, coluna );
		//utilidade += this.getUtilidadeVertical( linha, coluna );
		//utilidade += this.getUtilidadeDiagonalCrescente( linha, coluna );
		//utilidade += this.getUtilidadeDiagonalDecrescente( linha, coluna );
		
		this.inverteJogadores();
		return utilidade;
	}

	private int getUtilidadeHorizontal( int linha, int coluna ) {
		if( linha < 0 )
		{
			return 0;
		}
		
		int utilidade = 0;
		
		// vamos variar as posicoes em volta (na horizontal), na tentativa de achar algum quatro-em-linha
		int inicio = Math.max( coluna - 3, 0 );
		int fim = Math.min( coluna + 3, this.tabuleiro.length - 1 );
		
		for( int i = inicio; i <= coluna; i++ ) {
			// conta o numero de pecas da nossa cor nas quatro proximas posicoes
			int pecas = 0;
			
			// caso a busca va alem do tabuleiro, podemos considerar uma utilidade ruim
			if( i + 3 > fim )
			{
				utilidade = Math.max( 0, utilidade );
				continue;
			}
			
			boolean com_base = true;
			for( int k = i; k <= i + 3; k++ )
			{
				// se nao ha nada abaixo do item atual, nao ha perigo iminente
				if( linha + 1 < this.tabuleiro.length - 1 && this.tabuleiro[linha+1][k] == 0 )
				{
					com_base = false;
				}
				
				// System.out.println( "linha: " + linha + ", coluna: " + k + ", valor: " + this.tabuleiro[linha][k] );
				if( this.tabuleiro[linha][k] == this.cor )
				{
					pecas++;
				}
				else if( this.tabuleiro[linha][k] == this.adversario )
				{
					pecas = 0;
					break;
				}
			}
			
			if( pecas == 3 && !com_base )
			{
				pecas--;
			}
			
			// System.out.println( "a partir da coluna " + i + ", numero de H-pecas: " + pecas );
			utilidade = Math.max( pecas, utilidade );
		}

		if( utilidade == 2 )
		{
			utilidade = 40;
		}
		// caso haja algum local com utilidade 3 ele deve ser usado, SEMPRE
		else if( utilidade == 3 )
		{
			utilidade = 100;
		}
		
		// bonus para jogadas com pecas adjacentes
		utilidade += this.haPecasAdjacentes( linha, coluna );
		
		return utilidade;
	}

	private int getUtilidadeVertical( int linha, int coluna ) {
		if( linha < 0 )
		{
			return 0;
		}
		
		int utilidade = 0;
		// aqui basta descer tres niveis e checar as pecas encontradas
		int inicio = linha;
		// "descer" significa aumentar o numero das linhas
		int fim = Math.min( linha + 3, this.tabuleiro.length - 1 );
		for( int i = inicio; i <= fim; i++ )
		{	
			if( this.tabuleiro[i][coluna] == this.cor )
			{
				utilidade++;
			}
			// se encontrar uma peca do adversario abaixo, elimina qualquer sequencia nessa coluna (por agora)
			else if( this.tabuleiro[i][coluna] == this.adversario )
			{
				// utilidade = -1000;
				utilidade = 0;
				break;
			}
		}

		if( utilidade == 2 )
		{
			utilidade = 40;
		}
		// caso haja algum local com utilidade 3 ele deve ser usado, SEMPRE
		else if( utilidade == 3 )
		{
			utilidade = 100;
		}
		
		return utilidade;
	}

	private int getUtilidadeDiagonalCrescente( int linha, int coluna ) {
		if( linha < 0 )
		{
			return 0;
		}
		
		int utilidade = 0;
		
		// vamos variar as posicoes na diagonal, na tentativa de achar algum quatro-em-linha
		int linha_max = Math.min( linha + 3, this.tabuleiro.length - 1 );
		int coluna_max = Math.max( coluna - 3, 0 );
		// necessario saber o quanto podemos andar na diagonal sem sair do tabuleiro
		int max = Math.min( linha_max - linha, coluna - coluna_max );
		
		for( int i = 0; i <= max; i++ ) {
			// conta o numero de pecas da nossa cor nas quatro proximas posicoes
			int pecas = 0;
			
			// caso a busca va alem do tabuleiro, podemos considerar uma utilidade ruim
			if(
				linha + i > this.tabuleiro.length - 1 ||
				linha + i - 3 < 0 || 
				coluna - i < 0 ||
				coluna - i + 3 > this.tabuleiro.length - 1
			)
			{
				utilidade = Math.max( 0, utilidade );
				continue;
			}
			
			boolean com_base = true;
			for( int k = 0; k < 4; k++ )
			{
				int linha_alvo = linha + i - k;
				int coluna_alvo = coluna - i + k;
				
				// se nao ha nada abaixo do item atual, nao ha perigo iminente
				if( linha_alvo + 1 < this.tabuleiro.length - 1 && this.tabuleiro[linha_alvo+1][coluna_alvo] == 0 )
				{
					com_base = false;
				}
				
				if( this.tabuleiro[linha_alvo][coluna_alvo] == this.cor )
				{
					pecas++;
				}
				else if( this.tabuleiro[linha_alvo][coluna_alvo] == this.adversario )
				{
					pecas = 0;
					break;
				}
			}
			
			if( pecas == 3 && !com_base )
			{
				pecas--;
			}
			
			// System.out.println( "a partir da coluna " + i + ", numero de H-pecas: " + pecas );
			utilidade = Math.max( pecas, utilidade );
		}

		if( utilidade == 2 )
		{
			utilidade = 40;
		}
		// caso haja algum local com utilidade 3 ele deve ser usado, SEMPRE
		else if( utilidade == 3 )
		{
			utilidade = 100;
		}
		
		// bonus para jogadas com pecas adjacentes
		// utilidade += this.haPecasAdjacentes( linha, coluna );
		
		return utilidade;
	}

	private int getUtilidadeDiagonalDecrescente( int linha, int coluna ) {
		if( linha < 0 )
		{
			return 0;
		}
		
		int utilidade = 0;
		
		// vamos variar as posicoes na diagonal, na tentativa de achar algum quatro-em-linha
		int linha_max = Math.max( linha - 3, 0 );
		int coluna_max = Math.max( coluna - 3, 0 );
		// necessario saber o quanto podemos andar na diagonal sem sair do tabuleiro
		int max = Math.min( linha - linha_max, coluna - coluna_max );

		for( int i = 0; i <= max; i++ ) {
			// conta o numero de pecas da nossa cor nas quatro proximas posicoes
			int pecas = 0;
			
			// caso a busca va alem do tabuleiro, podemos considerar uma utilidade ruim
			if(
				linha - i < 0 ||
				linha - i + 3 > this.tabuleiro.length - 1 || 
				coluna - i < 0 ||
				coluna - i + 3 > this.tabuleiro.length - 1
			)
			{
				utilidade = Math.max( 0, utilidade );
				continue;
			}
			
			boolean com_base = true;
			for( int k = 0; k < 4; k++ )
			{	
				int linha_alvo = linha - i + k;
				int coluna_alvo = coluna - i + k;
				
				// se nao ha nada abaixo do item atual, nao ha perigo iminente
				if( linha_alvo + 1 < this.tabuleiro.length - 1 && this.tabuleiro[linha_alvo+1][coluna_alvo] == 0 )
				{
					com_base = false;
				}
				
				if( this.tabuleiro[linha_alvo][coluna_alvo] == this.cor )
				{
					pecas++;
				}
				else if( this.tabuleiro[linha_alvo][coluna_alvo] == this.adversario )
				{
					pecas = 0;
					break;
				}
			}
			
			if( pecas == 3 && !com_base )
			{
				pecas--;
			}
			
			// System.out.println( "a partir da coluna " + i + ", numero de H-pecas: " + pecas );
			utilidade = Math.max( pecas, utilidade );
		}
		
		if( utilidade == 2 )
		{
			utilidade = 30;
		}
		// caso haja algum local com utilidade 3 ele deve ser usado, SEMPRE
		else if( utilidade == 3 )
		{
			utilidade = 100;
		}
		
		// bonus para jogadas com pecas adjacentes
		// utilidade += this.haPecasAdjacentes( linha, coluna );
		
		return utilidade;
	}

	private int[][] getJogadasPossiveis() {
		int [][] jogadas = new int[this.tabuleiro.length][2];
		
		// this.imprimeArray( this.tabuleiro );
		
		// pega coluna a coluna
		for( int k = 0; k < this.tabuleiro[0].length; k++ )
		{
			// comeca com valores invalidos
			jogadas[k] = new int[] { -1, -1 };
			// subindo ate achar um 0
			for( int i = tabuleiro.length - 1; i >= 0; i-- )
			{
				if( this.tabuleiro[i][k] == 0 )
				{
					jogadas[k] = new int[] { i, k };
					break;
				}
			}
		}
		
		return jogadas;
	}

	private void inverteJogadores() {
		this.adversario = cor;
		this.cor = ( this.cor % 2 ) + 1;
	}

	private int haPecasAdjacentes( int linha, int coluna ) {
		int max = this.tabuleiro.length - 1;
		if( coluna - 1 < 0 || coluna + 1 > max )
		{
			return 0;
		}
		
		// locais horizontalmente adjacentes ganham bonus no calculo da utilidade
		if( this.tabuleiro[linha][coluna-1] == this.cor || this.tabuleiro[linha][coluna+1] == this.cor )
		{
			return 1;
		}
		return 0;
	}

	@Override
	public String getNome() {
		return "Manolo";
	}
}
