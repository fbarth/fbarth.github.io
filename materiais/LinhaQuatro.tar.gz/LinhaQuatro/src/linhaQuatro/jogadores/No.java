package linhaQuatro.jogadores;

public class No {
	private int jogada;
	public No filho; 
	
	public No(int jogada){
		this.jogada = jogada;
		filho = null;
	}
	public int getJogada(){
		return jogada;
	}
}
