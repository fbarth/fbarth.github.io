package linhaQuatro.jogadores;



public class Ameaca {
	

	
	int cor;
	int grau = 1;
	String faltam;
	String ameaca;
	
	public Ameaca(){
		
		
		
	}
	
	public void sobegrau() {
		grau++;
		
	} 
	
	
	
	
	

}
