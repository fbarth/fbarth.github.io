package linhaQuatro.jogadores;

/**
 *
 * @author Erick S. Miyazaki / Bruno Sa / Fernando Divanor
 */
public class JogadorGanhaNada implements Jogador
{
    int jogada = 0;
    public String getNome()
    {
        return ("GANHA NADA");
    }

    public int jogada(int[][] tabuleiro, int corDaMinhaBola)
    {
    	try
        {
            EstadoMinMaxAlphaBetaGanhaNada estado;
            //EstadoNegaScoutGanhaNada estado;

            if (corDaMinhaBola == 1)
            {
                estado = new EstadoMinMaxAlphaBetaGanhaNada(tabuleiro, corDaMinhaBola, 0, 2);
                //estado = new EstadoNegaScoutGanhaNada(tabuleiro,corDaMinhaBola,0,2);
            }
            else
            {
                estado = new EstadoMinMaxAlphaBetaGanhaNada(tabuleiro, corDaMinhaBola, 0, 1);
                //estado = new EstadoNegaScoutGanhaNada (tabuleiro, corDaMinhaBola, 0,3);
            }
            return MinMaxAlphaBetaGanhaNada.getJogada(estado,7);
            //return = NegaScoutGanhaNada.getJogada(estado,7);

        }
        catch(Exception e)
        {
            System.out.println("Erro: " + e);
            e.printStackTrace();
            return 0;
	}
    }
}
