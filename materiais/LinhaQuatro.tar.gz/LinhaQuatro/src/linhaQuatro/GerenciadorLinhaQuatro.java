package linhaQuatro;

import java.util.ArrayList;

import linhaQuatro.jogadores.BArkPlayer;
import linhaQuatro.jogadores.Jogador;
import linhaQuatro.jogadores.JogadorBGM;
import linhaQuatro.jogadores.JogadorByk;
import linhaQuatro.jogadores.JogadorGuru;
import linhaQuatro.jogadores.JogadorManolo;
import linhaQuatro.jogadores.TioDaPipoca;
import linhaQuatro.jogadores.BOPE.CoronelNascimento;

/**
 * Classe respons�vel por gerenciar os jogos.
 * 
 * @author Fabr�cio J. Barth
 * @version 06, junho, 2008
 *
 */
public class GerenciadorLinhaQuatro {
	
	public GerenciadorLinhaQuatro(){
		/**
		 * Jogadores que irao participar
		 * da competicao
		 * 
		 * Para inserir um novo jogador, insira aqui.
		 * 
		 * Jogadores das competicoes anteriores 2009/2, 2008/2, 2007/2
		 */
		ArrayList<Jogador> jogadores = new ArrayList<Jogador>();
		jogadores.add(new JogadorGuru());
		//jogadores.add(new HallanBatman());
		jogadores.add(new JogadorBGM());
		//jogadores.add(new JogadorTux());
		//jogadores.add(new JogadorBEst());
		//jogadores.add(new JogadorAlastor());
		//jogadores.add(new JogadorAleatorio());
		/*
		 * Jogadores do semestre 2010/02
		 */
		jogadores.add(new TioDaPipoca());
		jogadores.add(new BArkPlayer());
		jogadores.add(new CoronelNascimento());
		jogadores.add(new JogadorByk());
		jogadores.add(new JogadorManolo());
		
		/*
		 * Jogadores de outros semestres nao selecionados
		 * para a competicao de 2010/2 
		 */
		//jogadores.add(new Timao());
		//jogadores.add(new JogadorManual());
		//jogadores.add(new JogadorMDF());
		//jogadores.add(new JogadorPaquiderme1());
		//jogadores.add(new HallanBatman());
		//jogadores.add(new JogadorMinMax());
		//jogadores.add(new JogadorTux());
		//jogadores.add(new JogadorBGM());
		//jogadores.add(new JogadorARM2());
		//jogadores.add(new JogadorX());
		
		/*
		 * Jogos
		 */
		ArrayList<JogoLinhaQuatro> jogos = new ArrayList<JogoLinhaQuatro>();
		for(int i=0; i<jogadores.size(); i++){
			for(int j=i+1; j<jogadores.size(); j++){
				System.out.println("\nNovo jogo entre "+jogadores.get(i).getNome()+"  "+jogadores.get(j).getNome());
				jogos.add(new JogoLinhaQuatro(jogadores.get(i),jogadores.get(j)));
				System.out.println("\nNovo jogo entre "+jogadores.get(j).getNome()+"  "+jogadores.get(i).getNome());
				jogos.add(new JogoLinhaQuatro(jogadores.get(j),jogadores.get(i)));
			}
		}
		
		
		/**
		 * Resultados
		 */
		System.out.println("");
		System.out.println("Resultados da competi��o");
		for(int i=0; i<jogos.size(); i++){
			System.out.println(jogos.get(i).resultado());
		}
		
		/*
		 * Imprimindo apenas o nome dos vencedores
		 */
		System.out.println("");
		System.out.println("Imprimindo apenas o nome dos vencedores");
		for(int i=0; i<jogos.size(); i++){
			System.out.println(jogos.get(i).vencedor());
		}
	}
	
	public static void main(String args[]){
		new GerenciadorLinhaQuatro();
	}

}
